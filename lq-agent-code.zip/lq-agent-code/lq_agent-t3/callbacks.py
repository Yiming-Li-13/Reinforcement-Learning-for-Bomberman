import os
import pickle
import random
import numpy as np
import csv
import atexit
from collections import deque

ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']
TEST_LOG_FILE = "test_log.csv"

def setup(self):
    self.logger.debug("Successfully entered setup code")
    self.num_features = 31 # add more features

    if not hasattr(self, 'epsilon'):
        self.epsilon = 1.0 if self.train else 0.0

    self.last_position = None
    self.last_features = None
    self._test_last_state = None
    self._test_start_crates = None
    self._test_flushed = False
    # Keep recent positions for loop detection
    self.position_history = deque(maxlen=8)
    
    if not self.train:
        atexit.register(_flush_test_log, self)

    if self.train and not os.path.isfile("lq-model-t3.pt"):
        self.logger.debug("Initializing new linear model")
        self.model = np.random.normal(0, 0.1, (self.num_features, len(ACTIONS)))
    else:
        self.logger.debug("Loading existing linear model from lq-model-t3.pt")
        with open("lq-model-t3.pt", "rb") as file:
            self.model = pickle.load(file)

# Determine whether to commit suicide
def is_suicide(field, x, y, bombs, explosion_map, others_positions):
    danger_zone = np.zeros_like(field)
    simulated_bombs = bombs + [((x, y), 3)]
    bomb_xys = [b[0] for b in simulated_bombs]
    
    for (bx, by), t in simulated_bombs:
        danger_zone[bx, by] = 1
        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            for i in range(1, 4):
                nx, ny = bx + dx * i, by + dy * i
                if 0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]:
                    if field[nx, ny] == -1: break
                    danger_zone[nx, ny] = 1
                    
    danger_zone[explosion_map > 0] = 1
    
    queue = deque([(x, y, 0)])
    visited = {(x, y)}
    # Check if agent can reach a safe tile before the explosion
    while queue:
        cx, cy, dist = queue.popleft()
        if danger_zone[cx, cy] == 0: return False
        if dist >= 5: continue
            
        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]:
                if field[nx, ny] == 0 and (nx, ny) not in bomb_xys and (nx, ny) not in others_positions:
                    if (nx, ny) not in visited:
                        visited.add((nx, ny))
                        queue.append((nx, ny, dist + 1))
    return True

# Try to kill the enemy
def get_enemy_in_blast_zone(x, y, enemy_xys, field):
    for ex, ey in enemy_xys:
        if x == ex and abs(y - ey) <= 3:
            blocked = False
            for i in range(min(y, ey) + 1, max(y, ey)):
                if field[x, i] == -1: blocked = True; break
            if not blocked: return True
        if y == ey and abs(x - ex) <= 3:
            blocked = False
            for i in range(min(x, ex) + 1, max(x, ex)):
                if field[i, y] == -1: blocked = True; break
            if not blocked: return True
    return False


def act(self, game_state: dict) -> str:
    self.logger.info("Picking action using linear Q-model")
    
    if game_state['step'] == 1:
        if not self.train and self._test_last_state is not None:
            _log_test_round(self, self._test_last_state)
        self.last_position = None
        self._test_start_crates = int(np.sum(game_state['field'] == 1))
        self.position_history.clear()
        self.enemy_scores = {}

    self._test_last_state = game_state

    # Keep track of the highest score seen for each enemy
    if not hasattr(self, 'enemy_scores'):
        self.enemy_scores = {}
    for other in game_state['others']:
        name, score, _, _ = other
        self.enemy_scores[name] = max(self.enemy_scores.get(name, 0), score)

    x, y = game_state['self'][3]
    field = game_state['field']
    explosion_map = game_state['explosion_map']
    bombs = game_state['bombs']
    bomb_xys = [b[0] for b in bombs]
    others_xys = [other[3] for other in game_state['others']]
    can_bomb = game_state['self'][2]
    
    self.position_history.append((x, y))
    is_looping = len(self.position_history) == self.position_history.maxlen and len(set(self.position_history)) <= 3

    danger_all = np.zeros_like(field)
    danger_all[explosion_map > 0] = 1
    for (bx, by), t in bombs:
        danger_all[bx, by] = 1
        for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
            for i in range(1, 4):
                nx, ny = bx + dx*i, by + dy*i
                if 0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]:
                    if field[nx, ny] == -1: break
                    danger_all[nx, ny] = 1

    danger_next_step = np.zeros_like(field)
    for r in range(field.shape[0]):
        for c in range(field.shape[1]):
            if explosion_map[r, c] > 1:
                danger_next_step[r, c] = 1
    for (bx, by), t in bombs:
        if t == 0:
            danger_next_step[bx, by] = 1
            for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
                for i in range(1, 4):
                    nx, ny = bx + dx*i, by + dy*i
                    if 0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]:
                        if field[nx, ny] == -1: break
                        danger_next_step[nx, ny] = 1

    able_actions = ['WAIT']
    for a, (dx, dy) in zip(['UP', 'DOWN', 'LEFT', 'RIGHT'], [(0,-1), (0,1), (-1,0), (1,0)]):
        nx, ny = x + dx, y + dy
        if field[nx, ny] == 0 and (nx, ny) not in bomb_xys and (nx, ny) not in others_xys:
            able_actions.append(a)
            
    im_in_danger_now = danger_all[x, y] == 1
    
    # Check for crates directly next to the agent.
    adj_to_crate = (
        field[x-1, y] == 1 or field[x+1, y] == 1 or
        field[x, y-1] == 1 or field[x, y+1] == 1
    )
    
    # Allow bombing a nearby crate to break a movement loop.
    if can_bomb and not im_in_danger_now and not is_suicide(field, x, y, bombs, explosion_map, others_xys):
        if not is_looping or adj_to_crate:
            able_actions.append('BOMB')
            
    safe_actions = []

    if not im_in_danger_now:
        for a in able_actions:
            nx, ny = x, y
            if a == 'UP': ny -= 1
            elif a == 'DOWN': ny += 1
            elif a == 'LEFT': nx -= 1
            elif a == 'RIGHT': nx += 1
            
            if danger_all[nx, ny] == 0:
                safe_actions.append(a)
    else:
        for a in able_actions:
            nx, ny = x, y
            if a == 'UP': ny -= 1
            elif a == 'DOWN': ny += 1
            elif a == 'LEFT': nx -= 1
            elif a == 'RIGHT': nx += 1
            
            if danger_next_step[nx, ny] == 0:
                safe_actions.append(a)
                
    if len(safe_actions) > 0:
        valid_actions = safe_actions
    else:
        valid_actions = [a for a in able_actions if (a == 'WAIT' and danger_next_step[x, y] == 0) or 
                         (a != 'WAIT' and a != 'BOMB' and danger_next_step[x + (1 if a=='RIGHT' else -1 if a=='LEFT' else 0), 
                                                                           y + (1 if a=='DOWN' else -1 if a=='UP' else 0)] == 0)]
        if not valid_actions: valid_actions = able_actions

    if im_in_danger_now and 'WAIT' in valid_actions and len(valid_actions) > 1:
        valid_actions.remove('WAIT')
    self.logger.debug(f"Valid actions: {valid_actions}")
    
    if is_looping:
        self.logger.debug("Agent is stuck in a loop. Added BOMB if possible to attempt evasive maneuver.")

    features = state_to_features(game_state, prev_position=self.last_position)
    self.last_features = features
    
    if self.train and random.random() < self.epsilon:
        # Explore different actions during training
        self.logger.debug("Exploration active: Picking random valid action.")
        chosen = random.choice(valid_actions)
        self.last_position = (x, y)
        return chosen

    q_values = features @ self.model
    best_action = 'WAIT'
    best_q = -float('inf')

    for a in valid_actions:
        idx = ACTIONS.index(a)
        if q_values[idx] > best_q:
            best_q = q_values[idx]
            best_action = a

    self.logger.debug(f"Best Q-value {best_q:.4f} found. Chosen action: {best_action}")
    
    self.last_position = (x, y)
    return best_action


def state_to_features(game_state: dict, prev_position=None) -> np.array:
    if game_state is None: return None

    field = game_state['field']
    _, _, can_bomb, (x, y) = game_state['self']
    bombs = game_state['bombs']
    explosion_map = game_state['explosion_map']
    coins = game_state['coins']
    enemy_xys = [other[3] for other in game_state['others']]

    wall_up    = 1 if field[x, y - 1] == -1 else 0
    wall_down  = 1 if field[x, y + 1] == -1 else 0
    wall_left  = 1 if field[x - 1, y] == -1 else 0
    wall_right = 1 if field[x + 1, y] == -1 else 0

    # Confirm the surrounding boxes
    crate_adj_up    = 1 if field[x, y - 1] == 1 else 0
    crate_adj_down  = 1 if field[x, y + 1] == 1 else 0
    crate_adj_left  = 1 if field[x - 1, y] == 1 else 0
    crate_adj_right = 1 if field[x + 1, y] == 1 else 0

    danger_map = np.zeros_like(field)
    danger_map[explosion_map > 0] = 1
    free_space = (field == 0)
    for (bx, by), t in bombs:
        danger_map[bx, by] = 1
        for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
            for i in range(1, 4):
                nx, ny = bx + dx*i, by + dy*i
                if 0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]:
                    if field[nx, ny] == -1: break
                    danger_map[nx, ny] = 1

    im_in_danger = 1 if danger_map[x, y] > 0 else 0

    for (bx, by), t in bombs: free_space[bx, by] = False
    for ox, oy in enemy_xys: free_space[ox, oy] = False

    safe_dir = (0, 0)
    coin_dir = (0, 0)
    crate_dir = (0, 0)
    enemy_dir = (0, 0)

    if im_in_danger:
        safe_tiles = [(r, c) for r in range(field.shape[0]) for c in range(field.shape[1])
                      if danger_map[r, c] == 0 and free_space[r, c]]
        step, _ = look_for_targets(free_space, (x, y), safe_tiles)
        if step: safe_dir = (step[0] - x, step[1] - y)
    else:
        coin_step, coin_dist = look_for_targets(free_space, (x, y), coins)
        enemy_step, enemy_dist = look_for_targets(free_space, (x, y), enemy_xys)
        
        if coin_step and (not enemy_step or coin_dist <= enemy_dist):
            coin_dir = (coin_step[0] - x, coin_step[1] - y)
        elif enemy_step:
            enemy_dir = (enemy_step[0] - x, enemy_step[1] - y)
        else:
            crates = [(r, c) for r in range(field.shape[0]) for c in range(field.shape[1]) if field[r, c] == 1]
            crate_step, _ = look_for_targets(free_space, (x, y), crates)
            if crate_step:
                crate_dir = (crate_step[0] - x, crate_step[1] - y)

    back_dir = (0, 0)
    if prev_position is not None:
        px, py = prev_position
        if abs(px - x) + abs(py - y) == 1:
            back_dir = (px - x, py - y)
            
    enemy_in_blast = 1 if get_enemy_in_blast_zone(x, y, enemy_xys, field) else 0

    return np.array([
        wall_up, wall_down, wall_left, wall_right,
        im_in_danger,
        1 if safe_dir == (0, -1) else 0, 1 if safe_dir == (0, 1) else 0, 1 if safe_dir == (-1, 0) else 0, 1 if safe_dir == (1, 0) else 0,
        1 if coin_dir == (0, -1) else 0, 1 if coin_dir == (0, 1) else 0, 1 if coin_dir == (-1, 0) else 0, 1 if coin_dir == (1, 0) else 0,
        1 if crate_dir == (0, -1) else 0, 1 if crate_dir == (0, 1) else 0, 1 if crate_dir == (-1, 0) else 0, 1 if crate_dir == (1, 0) else 0,
        1 if can_bomb else 0,
        1 if back_dir == (0, -1) else 0, 1 if back_dir == (0, 1) else 0, 1 if back_dir == (-1, 0) else 0, 1 if back_dir == (1, 0) else 0,
        1 if enemy_dir == (0, -1) else 0, 1 if enemy_dir == (0, 1) else 0, 1 if enemy_dir == (-1, 0) else 0, 1 if enemy_dir == (1, 0) else 0,
        enemy_in_blast,
        # Keep the new crate features at the end
        crate_adj_up, crate_adj_down, crate_adj_left, crate_adj_right
    ])


def look_for_targets(free_space, start, targets):
    if len(targets) == 0: return None, float('inf')
    if start in targets: return start, 0
    frontier = deque([start])
    parent_dict = {start: start}
    
    while frontier:
        current = frontier.popleft()
        if current in targets:
            curr = current
            dist = 0
            while parent_dict[curr] != start:
                curr = parent_dict[curr]
                dist += 1
            return curr, dist + 1
            
        cx, cy = current
        for nx, ny in [(cx+1, cy), (cx-1, cy), (cx, cy+1), (cx, cy-1)]:
            if 0 <= nx < free_space.shape[0] and 0 <= ny < free_space.shape[1]:
                if (nx, ny) not in parent_dict:
                    if free_space[nx, ny] or (nx, ny) in targets:
                        parent_dict[(nx, ny)] = current
                        frontier.append((nx, ny))
    return None, float('inf')

# Save basic results for each test round
def _log_test_round(self, final_state):
    write_header = not os.path.isfile(TEST_LOG_FILE)
    field = final_state['field']
    remaining_crates = int(np.sum(field == 1))
    crates_destroyed = (self._test_start_crates or 0) - remaining_crates
    my_score = final_state['self'][1]
    steps = final_state['step']
    # get the highest score of the round
    max_enemy_score = max(self.enemy_scores.values()) if hasattr(self, 'enemy_scores') and self.enemy_scores else 0

    with open(TEST_LOG_FILE, "a", newline="") as f:
        w = csv.writer(f)
        if write_header:
            w.writerow(["round", "steps", "my_score", "max_enemy_score", "crates_destroyed"])
        w.writerow([final_state['round'], steps, my_score, max_enemy_score, crates_destroyed])

def _flush_test_log(self):
    if self._test_last_state is not None and not self._test_flushed:
        self._test_flushed = True
        _log_test_round(self, self._test_last_state)
