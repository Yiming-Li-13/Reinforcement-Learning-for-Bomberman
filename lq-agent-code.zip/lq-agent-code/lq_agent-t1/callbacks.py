import os
import pickle
import random
import numpy as np

ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT']  # 没有箱子，炸弹用不上

def setup(self):
    self.logger.debug("Successfully entered setup code")
    self.num_features = 12

    if not hasattr(self, 'epsilon'):
        self.epsilon = 1.0 if self.train else 0.0

    self.last_position = None
    self.last_features = None

    if self.train and not os.path.isfile("lq-model-t1.pt"):
        self.logger.debug("Initializing new linear model")
        self.model = np.random.normal(0, 0.1, (self.num_features, len(ACTIONS)))
    else:
        self.logger.debug("Loading existing linear model from my-linear-model.pt")
        with open("lq-model-t1.pt", "rb") as file:
            self.model = pickle.load(file)


def act(self, game_state: dict) -> str:
    self.logger.info("Picking action using linear Q-model")
    
    if game_state['step'] == 1:
        self.last_position = None

    x, y = game_state['self'][3]
    features = state_to_features(game_state, prev_position=self.last_position)
    self.last_features = features

    field = game_state['field']

    valid_actions = ['WAIT']
    if field[x, y - 1] == 0: valid_actions.append('UP')
    if field[x, y + 1] == 0: valid_actions.append('DOWN')
    if field[x - 1, y] == 0: valid_actions.append('LEFT')
    if field[x + 1, y] == 0: valid_actions.append('RIGHT')

    self.logger.debug(f"Valid actions: {valid_actions}")

    if self.train and random.random() < self.epsilon:
        self.logger.debug("Exploration active: Picking random valid action.")
        chosen = random.choice(valid_actions)
        self.last_position = (x, y)
        return chosen

    q_values = features @ self.model
    best_action = 'WAIT'
    best_q = -float('inf')
    for a in valid_actions:
        idx = ACTIONS.index(a)
        if q_values[idx] > best_q:
            best_q = q_values[idx]
            best_action = a

    self.logger.debug(f"Best Q-value {best_q:.4f} found. Chosen action: {best_action}")

    self.last_position = (x, y)
    return best_action


def state_to_features(game_state: dict, prev_position=None) -> np.array:
    if game_state is None: return None

    field = game_state['field']
    _, _, _, (x, y) = game_state['self']
    coins = game_state['coins']

    wall_up    = 1 if field[x, y - 1] == -1 else 0
    wall_down  = 1 if field[x, y + 1] == -1 else 0
    wall_left  = 1 if field[x - 1, y] == -1 else 0
    wall_right = 1 if field[x + 1, y] == -1 else 0

    free_space = (field == 0)

    coin_dir = (0, 0)
    if len(coins) > 0:
        step = look_for_targets(free_space, (x, y), coins)
        if step: coin_dir = (step[0] - x, step[1] - y)

    back_dir = (0, 0)
    if prev_position is not None:
        px, py = prev_position
        if abs(px - x) + abs(py - y) == 1:
            back_dir = (px - x, py - y)

    return np.array([
        wall_up, wall_down, wall_left, wall_right,
        1 if coin_dir == (0, -1) else 0, 1 if coin_dir == (0, 1) else 0, 1 if coin_dir == (-1, 0) else 0, 1 if coin_dir == (1, 0) else 0,
        1 if back_dir == (0, -1) else 0, 1 if back_dir == (0, 1) else 0, 1 if back_dir == (-1, 0) else 0, 1 if back_dir == (1, 0) else 0,
    ])


def look_for_targets(free_space, start, targets):
    if len(targets) == 0: return None
    frontier = [start]
    parent_dict = {start: start}
    best_pos = start
    best_dist = min(abs(t[0] - start[0]) + abs(t[1] - start[1]) for t in targets)
    
    while len(frontier) > 0:
        current = frontier.pop(0)
        dist = min(abs(t[0] - current[0]) + abs(t[1] - current[1]) for t in targets)
        if dist < best_dist:
            best_dist = dist
            best_pos = current
        if current in targets:
            best_pos = current
            break
        x, y = current
        neighbors = [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
        for nx, ny in neighbors:
            if 0 <= nx < free_space.shape[0] and 0 <= ny < free_space.shape[1]:
                if free_space[nx, ny] and (nx, ny) not in parent_dict:
                    frontier.append((nx, ny))
                    parent_dict[(nx, ny)] = current
                    
    if best_pos == start: return None
    current = best_pos
    while parent_dict[current] != start:
        current = parent_dict[current]
    return current
