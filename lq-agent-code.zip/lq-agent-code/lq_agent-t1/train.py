# task1
import os
import csv
import pickle
import numpy as np
import events as e
from .callbacks import state_to_features, ACTIONS

LOG_FILE = "training_log-t1.csv"

def setup_training(self):
    self.alpha = 0.05
    self.gamma = 0.9
    self.episode_coins = 0
    self.episode_oscillations = 0
    self.steps_since_progress = 0

    if not os.path.isfile(LOG_FILE):
        with open(LOG_FILE, "w", newline="") as f:
            csv.writer(f).writerow(["round", "steps", "score", "coins_collected", "oscillations", "epsilon"])


def game_events_occurred(self, old_game_state: dict, self_action: str, new_game_state: dict, events: list):
    old_features = self.last_features

    if old_game_state is not None and old_features is not None:
        coin_up, coin_down, coin_left, coin_right = old_features[4:8]
        back_up, back_down, back_left, back_right = old_features[8:12]

        def matches(up, down, left, right):
            return (self_action == 'UP' and up) or (self_action == 'DOWN' and down) or \
                   (self_action == 'LEFT' and left) or (self_action == 'RIGHT' and right)

        has_forward_signal = coin_up or coin_down or coin_left or coin_right
        if has_forward_signal:
            if matches(coin_up, coin_down, coin_left, coin_right):
                events.append("MOVED_TOWARDS_COIN")
            else:
                events.append("MOVED_AWAY_FROM_COIN")

        if has_forward_signal and matches(back_up, back_down, back_left, back_right):
            events.append("OSCILLATED")
            self.episode_oscillations += 1

    self.episode_coins += events.count(e.COIN_COLLECTED)

    progress_made = e.COIN_COLLECTED in events
    self.steps_since_progress = 0 if progress_made else self.steps_since_progress + 1
    idle_penalty = -min(5.0, 0.1 * max(0, self.steps_since_progress - 20))

    new_prev_position = None if old_game_state is None else old_game_state['self'][3]
    new_features = state_to_features(new_game_state, prev_position=new_prev_position)

    reward = reward_from_events(self, events) + idle_penalty
    action_idx = ACTIONS.index(self_action)
    
    # Standard Q-learning update
    old_q = old_features @ self.model[:, action_idx]
    max_new_q = 0 if new_game_state is None else np.max(new_features @ self.model)
    
    td_target = reward + self.gamma * max_new_q
    td_error = td_target - old_q
    self.model[:, action_idx] += self.alpha * td_error * old_features


def end_of_round(self, last_game_state: dict, last_action: str, events: list):
    game_events_occurred(self, last_game_state, last_action, None, events)

    with open(LOG_FILE, "a", newline="") as f:
        csv.writer(f).writerow([
            last_game_state['round'], last_game_state['step'], last_game_state['self'][1],
            self.episode_coins, self.episode_oscillations,
            round(self.epsilon, 4) if hasattr(self, 'epsilon') else "",
        ])

    self.episode_coins = 0
    self.episode_oscillations = 0
    self.steps_since_progress = 0

    if hasattr(self, 'epsilon'):
        self.epsilon = max(0.05, self.epsilon * 0.99)

    with open("lq-model-t1.pt", "wb") as file:
        pickle.dump(self.model, file)


def reward_from_events(self, events: list) -> float:
    game_rewards = {
        e.COIN_COLLECTED: 10,
        e.INVALID_ACTION: -2,
        e.WAITED: -1,
        "MOVED_TOWARDS_COIN": 2,
        "MOVED_AWAY_FROM_COIN": -2,
        "OSCILLATED": -3,
        e.SURVIVED_ROUND: 1,
    }
    return sum(game_rewards.get(event, 0) for event in events)