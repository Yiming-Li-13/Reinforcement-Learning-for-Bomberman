import os
import pickle
import random
import numpy as np
import csv
import atexit
from collections import deque

ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']
TEST_LOG_FILE = "test_log.csv"

def setup(self):
    self.logger.debug("Successfully entered setup code")
    self.num_features = 22 # add more features

    if not hasattr(self, 'epsilon'):
        self.epsilon = 1.0 if self.train else 0.0

    self.last_position = None
    self.last_features = None
    self._test_last_state = None
    self._test_start_crates = None
    self._test_flushed = False
    if not self.train:
        atexit.register(_flush_test_log, self)

    if self.train and not os.path.isfile("lq-model-t2.pt"):
        self.logger.debug("Initializing new linear model")
        self.model = np.random.normal(0, 0.1, (self.num_features, len(ACTIONS)))
    else:
        self.logger.debug("Loading existing linear model from my-linear-model.pt")
        with open("lq-model-t2.pt", "rb") as file:
            self.model = pickle.load(file)

# Determine whether to commit suicide
def is_suicide(field, x, y, bombs, explosion_map, others_positions=(), bomb_timer=3):
    danger_map = np.zeros_like(field)
    danger_map[explosion_map > 0] = 1
    simulated_bombs = bombs + [((x, y), bomb_timer)]
    bomb_positions = [b[0] for b in simulated_bombs]

    for (bx, by), t in simulated_bombs:
        danger_map[bx, by] = 1
        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            for i in range(1, 4):
                nx, ny = bx + dx * i, by + dy * i
                if field[nx, ny] == -1: break
                danger_map[nx, ny] = 1

    queue = deque([(x, y, 0)])
    visited = {(x, y)}
    # Check if agent can reach a safe tile before the explosion
    while queue:
        cx, cy, dist = queue.popleft()
        if danger_map[cx, cy] == 0: return False
        if dist >= 4: continue

        for nx, ny in [(cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)]:
            if 0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]:
                if field[nx, ny] == 0 and (nx, ny) not in bomb_positions and (nx, ny) not in others_positions:
                    if (nx, ny) not in visited:
                        visited.add((nx, ny))
                        queue.append((nx, ny, dist + 1))
    return True


def act(self, game_state: dict) -> str:
    self.logger.info("Picking action using linear Q-model")
    
    if game_state['step'] == 1:
        if not self.train and self._test_last_state is not None:
            _log_test_round(self, self._test_last_state)
        self.last_position = None
        self._test_start_crates = int(np.sum(game_state['field'] == 1))

    self._test_last_state = game_state

    x, y = game_state['self'][3]
    features = state_to_features(game_state, prev_position=self.last_position)
    self.last_features = features

    field = game_state['field']
    explosion_map = game_state['explosion_map']
    bombs = game_state['bombs']
    bomb_xys = [b[0] for b in bombs]
    can_bomb = game_state['self'][2]

    valid_actions = ['WAIT']

    if field[x, y - 1] == 0 and (x, y - 1) not in bomb_xys and explosion_map[x, y - 1] == 0: valid_actions.append('UP')
    if field[x, y + 1] == 0 and (x, y + 1) not in bomb_xys and explosion_map[x, y + 1] == 0: valid_actions.append('DOWN')
    if field[x - 1, y] == 0 and (x - 1, y) not in bomb_xys and explosion_map[x - 1, y] == 0: valid_actions.append('LEFT')
    if field[x + 1, y] == 0 and (x + 1, y) not in bomb_xys and explosion_map[x + 1, y] == 0: valid_actions.append('RIGHT')
    if can_bomb and not is_suicide(field, x, y, bombs, explosion_map):
        valid_actions.append('BOMB')

     # Avoid waiting when there is an immediate danger
    im_in_danger = features[4] == 1 
    if im_in_danger and 'WAIT' in valid_actions and len(valid_actions) > 1:
        valid_actions.remove('WAIT')
        self.logger.debug("Agent is in danger, WAIT action removed.")

    self.logger.debug(f"Valid actions: {valid_actions}")
    if self.train and random.random() < self.epsilon:
        # Explore different actions during training
        self.logger.debug("Exploration active: Picking random valid action.")
        chosen = random.choice(valid_actions)
        self.last_position = (x, y)
        return chosen

    q_values = features @ self.model
    best_action = 'WAIT'
    best_q = -float('inf')

    for a in valid_actions:
        idx = ACTIONS.index(a)
        if q_values[idx] > best_q:
            best_q = q_values[idx]
            best_action = a

    self.logger.debug(f"Best Q-value {best_q:.4f} found. Chosen action: {best_action}")
    self.last_position = (x, y)
    return best_action


def state_to_features(game_state: dict, prev_position=None) -> np.array:
    if game_state is None: return None

    field = game_state['field']
    _, _, can_bomb, (x, y) = game_state['self']
    bombs = game_state['bombs']
    explosion_map = game_state['explosion_map']
    coins = game_state['coins']

    wall_up    = 1 if field[x, y - 1] == -1 else 0
    wall_down  = 1 if field[x, y + 1] == -1 else 0
    wall_left  = 1 if field[x - 1, y] == -1 else 0
    wall_right = 1 if field[x + 1, y] == -1 else 0

    danger_map = np.zeros_like(field)
    danger_map[explosion_map > 0] = 1
    free_space = (field == 0)
    for (bx, by), t in bombs:
        free_space[bx, by] = False
        danger_map[bx, by] = 1
        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            for i in range(1, 4):
                nx, ny = bx + dx * i, by + dy * i
                if field[nx, ny] == -1:
                    break
                danger_map[nx, ny] = 1

    im_in_danger = 1 if danger_map[x, y] > 0 else 0

    safe_dir = (0, 0)
    coin_dir = (0, 0)
    crate_dir = (0, 0)

    if im_in_danger:
        safe_tiles = [(r, c) for r in range(field.shape[0]) for c in range(field.shape[1])
                      if danger_map[r, c] == 0 and free_space[r, c]]
        step = look_for_targets(free_space, (x, y), safe_tiles)
        if step: safe_dir = (step[0] - x, step[1] - y)

    coin_step = None
    if len(coins) > 0 and not im_in_danger:
        coin_step = look_for_targets(free_space, (x, y), coins)
        if coin_step: coin_dir = (coin_step[0] - x, coin_step[1] - y)

    crates = [(r, c) for r in range(field.shape[0]) for c in range(field.shape[1]) if field[r, c] == 1]
    if coin_step is None and len(crates) > 0 and not im_in_danger:
        step = look_for_targets(free_space, (x, y), crates)
        if step: crate_dir = (step[0] - x, step[1] - y)

    back_dir = (0, 0)
    if prev_position is not None:
        px, py = prev_position
        if abs(px - x) + abs(py - y) == 1:
            back_dir = (px - x, py - y)

    return np.array([
        wall_up, wall_down, wall_left, wall_right,
        im_in_danger,
        1 if safe_dir == (0, -1) else 0, 1 if safe_dir == (0, 1) else 0, 1 if safe_dir == (-1, 0) else 0, 1 if safe_dir == (1, 0) else 0,
        1 if coin_dir == (0, -1) else 0, 1 if coin_dir == (0, 1) else 0, 1 if coin_dir == (-1, 0) else 0, 1 if coin_dir == (1, 0) else 0,
        1 if crate_dir == (0, -1) else 0, 1 if crate_dir == (0, 1) else 0, 1 if crate_dir == (-1, 0) else 0, 1 if crate_dir == (1, 0) else 0,
        1 if can_bomb else 0,
        1 if back_dir == (0, -1) else 0, 1 if back_dir == (0, 1) else 0, 1 if back_dir == (-1, 0) else 0, 1 if back_dir == (1, 0) else 0,
    ])


def look_for_targets(free_space, start, targets):
    if len(targets) == 0: return None
    frontier = [start]
    parent_dict = {start: start}
    best_pos = start
    best_dist = min(abs(t[0] - start[0]) + abs(t[1] - start[1]) for t in targets)

    while len(frontier) > 0:
        current = frontier.pop(0)
        dist = min(abs(t[0] - current[0]) + abs(t[1] - current[1]) for t in targets)
        if dist < best_dist:
            best_dist = dist
            best_pos = current
        if current in targets:
            best_pos = current
            break
        x, y = current
        neighbors = [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
        for nx, ny in neighbors:
            if 0 <= nx < free_space.shape[0] and 0 <= ny < free_space.shape[1]:
                if free_space[nx, ny] and (nx, ny) not in parent_dict:
                    frontier.append((nx, ny))
                    parent_dict[(nx, ny)] = current
    if best_pos == start: return None
    current = best_pos
    while parent_dict[current] != start:
        current = parent_dict[current]
    return current

# Save basic results for each test round
def _log_test_round(self, final_state):
    write_header = not os.path.isfile(TEST_LOG_FILE)
    field = final_state['field']
    remaining_crates = int(np.sum(field == 1))
    crates_destroyed = (self._test_start_crates or 0) - remaining_crates
    score = final_state['self'][1]
    steps = final_state['step']

    with open(TEST_LOG_FILE, "a", newline="") as f:
        w = csv.writer(f)
        if write_header:
            w.writerow(["round", "steps", "score", "coins_collected", "crates_destroyed", "self_kill"])
        w.writerow([final_state['round'], steps, score, score, crates_destroyed, 1 if steps < 400 else 0])


def _flush_test_log(self):
    if self._test_last_state is not None and not self._test_flushed:
        self._test_flushed = True
        _log_test_round(self, self._test_last_state)
