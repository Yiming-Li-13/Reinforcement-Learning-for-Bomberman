import os
import csv
import pickle
import numpy as np
import events as e
from collections import deque
from .callbacks import state_to_features, ACTIONS

LOG_FILE = "training_log-t2.csv"

def setup_training(self):
    self.alpha = 0.05
    self.gamma = 0.9
    self.episode_coins = 0
    self.episode_crates = 0
    self.episode_self_kill = 0
    self.episode_stuck_loops = 0
    self.recent_positions = deque(maxlen=8)

    if not os.path.isfile(LOG_FILE):
        with open(LOG_FILE, "w", newline="") as f:
            csv.writer(f).writerow(
                ["round", "steps", "score", "coins_collected", "crates_destroyed",
                 "self_kill", "stuck_loops", "epsilon"]
            )


def game_events_occurred(self, old_game_state: dict, self_action: str, new_game_state: dict, events: list):
    old_features = self.last_features

    if old_game_state is not None and old_features is not None:
        im_in_danger = old_features[4]
        safe_up, safe_down, safe_left, safe_right = old_features[5:9]
        coin_up, coin_down, coin_left, coin_right = old_features[9:13]
        crate_up, crate_down, crate_left, crate_right = old_features[13:17]

        def matches(up, down, left, right):
            return (self_action == 'UP' and up) or (self_action == 'DOWN' and down) or \
                   (self_action == 'LEFT' and left) or (self_action == 'RIGHT' and right)

        if im_in_danger:
            if matches(safe_up, safe_down, safe_left, safe_right):
                events.append("MOVED_TOWARDS_SAFE_PLACE")
            else:
                events.append("MOVED_INTO_DANGER")
        elif coin_up or coin_down or coin_left or coin_right:
            if matches(coin_up, coin_down, coin_left, coin_right):
                events.append("MOVED_TOWARDS_COIN")
            else:
                events.append("MOVED_AWAY_FROM_COIN")
        elif crate_up or crate_down or crate_left or crate_right:
            if matches(crate_up, crate_down, crate_left, crate_right):
                events.append("MOVED_TOWARDS_CRATE")
            else:
                events.append("MOVED_AWAY_FROM_CRATE")

        if self_action == 'BOMB' and e.BOMB_DROPPED in events:
            ox, oy = old_game_state['self'][3]
            old_field = old_game_state['field']
            near_crate = (
                old_field[ox - 1, oy] == 1 or old_field[ox + 1, oy] == 1 or
                old_field[ox, oy - 1] == 1 or old_field[ox, oy + 1] == 1
            )
            events.append("GOOD_BOMB_NEAR_CRATE" if near_crate else "USELESS_BOMB")

    if new_game_state is not None:
        self.recent_positions.append(new_game_state['self'][3])
        if len(self.recent_positions) == self.recent_positions.maxlen:
            if len(set(self.recent_positions)) <= 3:
                events.append("STUCK_IN_LOOP")
                self.episode_stuck_loops += 1

    self.episode_coins += events.count(e.COIN_COLLECTED)
    self.episode_crates += events.count(e.CRATE_DESTROYED)
    if e.KILLED_SELF in events:
        self.episode_self_kill = 1

    new_prev_position = None if old_game_state is None else old_game_state['self'][3]
    new_features = state_to_features(new_game_state, prev_position=new_prev_position)

    reward = reward_from_events(self, events)
    action_idx = ACTIONS.index(self_action)
    
    # Standard Q-learning update
    old_q = old_features @ self.model[:, action_idx]
    max_new_q = 0 if new_game_state is None else np.max(new_features @ self.model)
    
    td_target = reward + self.gamma * max_new_q
    td_error = td_target - old_q
    self.model[:, action_idx] += self.alpha * td_error * old_features


def end_of_round(self, last_game_state: dict, last_action: str, events: list):
    game_events_occurred(self, last_game_state, last_action, None, events)

    with open(LOG_FILE, "a", newline="") as f:
        csv.writer(f).writerow([
            last_game_state['round'],
            last_game_state['step'],
            last_game_state['self'][1],
            self.episode_coins,
            self.episode_crates,
            self.episode_self_kill,
            self.episode_stuck_loops,
            round(self.epsilon, 4) if hasattr(self, 'epsilon') else "",
        ])

    self.episode_coins = 0
    self.episode_crates = 0
    self.episode_self_kill = 0
    self.episode_stuck_loops = 0
    self.recent_positions.clear()

    if hasattr(self, 'epsilon'):
        self.epsilon = max(0.05, self.epsilon * 0.997)  

    with open("lq-model-t2.pt", "wb") as file:
        pickle.dump(self.model, file)


def reward_from_events(self, events: list) -> float:
    game_rewards = {
        e.COIN_COLLECTED: 10,
        e.CRATE_DESTROYED: 5,
        e.KILLED_SELF: -30,
        e.INVALID_ACTION: -2,
        e.WAITED: -1,
        "GOOD_BOMB_NEAR_CRATE": 3,
        "USELESS_BOMB": -5,
        "MOVED_TOWARDS_COIN": 2,
        "MOVED_AWAY_FROM_COIN": -2,
        "MOVED_TOWARDS_CRATE": 1,
        "MOVED_AWAY_FROM_CRATE": -1,
        "MOVED_TOWARDS_SAFE_PLACE": 5,
        "MOVED_INTO_DANGER": -10,
        "STUCK_IN_LOOP": -5,
        e.SURVIVED_ROUND: 1,
    }

    return sum(game_rewards.get(event, 0) for event in events if event != e.BOMB_DROPPED)