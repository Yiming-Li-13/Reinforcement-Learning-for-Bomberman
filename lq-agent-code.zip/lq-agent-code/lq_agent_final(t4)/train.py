import os
import csv
import pickle
import numpy as np
import events as e
from collections import deque
from .callbacks import state_to_features, ACTIONS, get_valid_actions

LOG_FILE = "training_log-final.csv"

MOVE_ACTIONS = ('UP', 'DOWN', 'LEFT', 'RIGHT')


def setup_training(self):
    self.alpha = 0.1
    self.gamma = 0.9
    self.episode_coins = 0
    self.episode_crates = 0
    self.episode_kills = 0
    self.episode_self_kill = 0
    self.episode_stuck_loops = 0
    self.recent_positions = deque(maxlen=12)

    if not os.path.isfile(LOG_FILE):
        with open(LOG_FILE, "w", newline="") as f:
            csv.writer(f).writerow(
                ["round", "steps", "score", "coins_collected", "crates_destroyed", "kills",
                 "self_kill", "stuck_loops", "epsilon"]
            )


def game_events_occurred(self, old_game_state: dict, self_action: str,
                         new_game_state: dict, events: list):

    old_features = self.last_features
    has_old = old_game_state is not None and old_features is not None

    if has_old:
        im_in_danger = old_features[4]
        safe_up, safe_down, safe_left, safe_right = old_features[5:9]
        coin_up, coin_down, coin_left, coin_right = old_features[9:13]
        crate_up, crate_down, crate_left, crate_right = old_features[13:17]
        enemy_up, enemy_down, enemy_left, enemy_right = old_features[22:26]
        enemy_in_blast = old_features[26]

        def matches(up, down, left, right):
            return (self_action == 'UP' and up) or (self_action == 'DOWN' and down) or \
                   (self_action == 'LEFT' and left) or (self_action == 'RIGHT' and right)

        if self_action in MOVE_ACTIONS:
            if im_in_danger:
                if matches(safe_up, safe_down, safe_left, safe_right):
                    events.append("MOVED_TOWARDS_SAFE_PLACE")
                else:
                    events.append("MOVED_INTO_DANGER")
            elif coin_up or coin_down or coin_left or coin_right:
                if matches(coin_up, coin_down, coin_left, coin_right):
                    events.append("MOVED_TOWARDS_COIN")
                else:
                    events.append("MOVED_AWAY_FROM_COIN")
            elif enemy_up or enemy_down or enemy_left or enemy_right:
                if matches(enemy_up, enemy_down, enemy_left, enemy_right):
                    events.append("MOVED_TOWARDS_ENEMY")
                else:
                    events.append("MOVED_AWAY_FROM_ENEMY")
            elif crate_up or crate_down or crate_left or crate_right:
                if matches(crate_up, crate_down, crate_left, crate_right):
                    events.append("MOVED_TOWARDS_CRATE")
                else:
                    events.append("MOVED_AWAY_FROM_CRATE")

        if self_action == 'WAIT' and not im_in_danger:
            events.append("WAITED_WHILE_SAFE")

        if self_action == 'BOMB' and e.BOMB_DROPPED in events:
            if enemy_in_blast:
                events.append("GOOD_BOMB_NEAR_ENEMY")
            else:
                ox, oy = old_game_state['self'][3]
                old_field = old_game_state['field']
                near_crate = (
                    old_field[ox - 1, oy] == 1 or old_field[ox + 1, oy] == 1 or
                    old_field[ox, oy - 1] == 1 or old_field[ox, oy + 1] == 1
                )
                events.append("GOOD_BOMB_NEAR_CRATE" if near_crate else "USELESS_BOMB")

    is_looping_next = False
    if new_game_state is not None:
        self.recent_positions.append(new_game_state['self'][3])

        if len(self.recent_positions) >= 3 and has_old:
            if self.recent_positions[-1] == self.recent_positions[-3]:
                if not old_features[4]:      # no penalty for turning back to avoid the bomb
                    events.append("STEPPED_BACK")

        if len(self.recent_positions) == self.recent_positions.maxlen:
            if len(set(self.recent_positions)) <= 3:
                is_looping_next = True
                events.append("STUCK_IN_LOOP")
                self.episode_stuck_loops += 1

    self.episode_coins += events.count(e.COIN_COLLECTED)
    self.episode_crates += events.count(e.CRATE_DESTROYED)
    self.episode_kills += events.count(e.KILLED_OPPONENT)
    if e.KILLED_SELF in events:
        self.episode_self_kill = 1

    if not has_old:
        return

    new_prev_position = old_game_state['self'][3]
    new_features = state_to_features(new_game_state, prev_position=new_prev_position,
                                     is_looping=is_looping_next)

    reward = reward_from_events(self, events)
    action_idx = ACTIONS.index(self_action)
    old_q = old_features @ self.model[:, action_idx]

    if new_game_state is None:
        max_new_q = 0.0
    else:
        valid_next_actions = get_valid_actions(self, new_game_state, is_looping_next)
        q_vals = new_features @ self.model
        valid_q_vals = [q_vals[ACTIONS.index(a)] for a in valid_next_actions]
        max_new_q = max(valid_q_vals) if valid_q_vals else 0.0

    td_error = float(np.clip(reward + self.gamma * max_new_q - old_q, -100.0, 100.0))
    norm = max(float(old_features @ old_features), 1.0)
    self.model[:, action_idx] += (self.alpha / norm) * td_error * old_features


def end_of_round(self, last_game_state: dict, last_action: str, events: list):
    game_events_occurred(self, last_game_state, last_action, None, events)

    with open(LOG_FILE, "a", newline="") as f:
        csv.writer(f).writerow([
            last_game_state['round'],
            last_game_state['step'],
            last_game_state['self'][1],
            self.episode_coins,
            self.episode_crates,
            self.episode_kills,
            self.episode_self_kill,
            self.episode_stuck_loops,
            round(self.epsilon, 4) if hasattr(self, 'epsilon') else "",
        ])

    self.episode_coins = 0
    self.episode_crates = 0
    self.episode_kills = 0
    self.episode_self_kill = 0
    self.episode_stuck_loops = 0
    self.recent_positions.clear()
    self.last_features = None

    if hasattr(self, 'epsilon'):
        self.epsilon = max(0.05, self.epsilon * 0.998)

    with open("lq-model-final.pt", "wb") as file:
        pickle.dump({'model': self.model, 'epsilon': self.epsilon}, file)


def reward_from_events(self, events: list) -> float:
    game_rewards = {
        e.COIN_COLLECTED: 15,            
        e.KILLED_OPPONENT: 75,          # The ratio remains at 1:5
        e.CRATE_DESTROYED: 2,
        e.GOT_KILLED: -60,
        e.KILLED_SELF: -60,            # Self-exploding will trigger GOT_KILLED at the same time
        "GOOD_BOMB_NEAR_ENEMY": 10,
        "MOVED_TOWARDS_ENEMY": 3,
        "MOVED_AWAY_FROM_ENEMY": -3,
        "GOOD_BOMB_NEAR_CRATE": 3,
        "USELESS_BOMB": -15,
        "MOVED_TOWARDS_COIN": 5,
        "MOVED_AWAY_FROM_COIN": -5,
        "MOVED_TOWARDS_CRATE": 2,
        "MOVED_AWAY_FROM_CRATE": -2,
        "MOVED_TOWARDS_SAFE_PLACE": 3,
        "MOVED_INTO_DANGER": -6,
        "STEPPED_BACK": -4,
        "STUCK_IN_LOOP": -5,
        "WAITED_WHILE_SAFE": -2,
        e.INVALID_ACTION: -5,
        e.SURVIVED_ROUND: 10,          
    }
    return sum(game_rewards.get(event, 0) for event in events)
