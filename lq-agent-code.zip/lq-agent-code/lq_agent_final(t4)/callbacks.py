import os
import pickle
import random
import numpy as np
import csv
import atexit
from collections import deque

ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB']
AGENT_DIR = os.path.dirname(__file__)
BOMB_POWER = 3        
BOMB_TIMER = 4       
EXPLOSION_LETHAL = 2  
MOVES = [('UP', (0, -1)), ('DOWN', (0, 1)), ('LEFT', (-1, 0)),
         ('RIGHT', (1, 0)), ('WAIT', (0, 0))]
DELTA = dict(MOVES)

def setup(self):
    self.logger.debug("Successfully entered setup code")
    self.num_features = 36 # add more features
    self.last_position = None
    self.last_features = None
    self._test_last_state = None
    self._test_start_crates = None
    self._test_flushed = False
    self.position_history = deque(maxlen=12)

    if not self.train:
        atexit.register(_flush_test_log, self)

    if self.train and not os.path.isfile("lq-model-final.pt"):
        self.model = np.random.normal(0, 0.1, (self.num_features, len(ACTIONS)))
        self.epsilon = 1.0
    else:
        with open("lq-model-final.pt", "rb") as file:
            data = pickle.load(file)
            if isinstance(data, dict):
                self.model = data['model']
                self.epsilon = max(data.get('epsilon', 0.0), 0.2 if self.train else 0.0)
            else:
                self.model = data
                self.epsilon = 0.5 if self.train else 0.0

    if not self.train:
        self.epsilon = 0.0

# Calculate the range of the bomb explosion
def blast_coords(field, bx, by):
    coords = [(bx, by)]
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        for i in range(1, BOMB_POWER + 1):
            nx, ny = bx + dx * i, by + dy * i
            if not (0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]):
                break
            if field[nx, ny] == -1:
                break
            coords.append((nx, ny))
            if field[nx, ny] == 1:
                break
    return coords

# Look for a safe way
def danger_horizon(bombs, explosion_map):
    h = int(explosion_map.max()) if explosion_map.size else 0
    for (_, _), timer in bombs:
        h = max(h, int(timer) + EXPLOSION_LETHAL)
    return max(h, 1)


def build_danger(field, bombs, explosion_map, horizon):
    """
    Build a time-based danger map for bombs and explosions.
    """
    danger = np.zeros((horizon + 1,) + field.shape, dtype=bool)
    # Mark cells that are already on fire
    xs, ys = np.nonzero(explosion_map > 0)
    for x, y in zip(xs, ys):
        life = int(explosion_map[x, y])
        for t in range(1, min(life, horizon)+ 1):
            danger[t, x, y] = True
    # Mark future bomb explosions
    for (bx, by), timer in bombs:
        boom = int(timer) + 1
        if boom > horizon:
            continue
        cells = blast_coords(field, bx, by)
        for t in range(boom, min(boom + EXPLOSION_LETHAL - 1, horizon) + 1):
            for (cx, cy) in cells:
                danger[t, cx, cy] = True
    # Store the last dangerous time for each cell
    last_danger = np.zeros(field.shape, dtype=np.int16)
    for t in range(1, horizon + 1):
        last_danger[danger[t]] = t
    return danger, last_danger


def can_survive(field, start, t0, danger, last_danger, blocked, horizon):
    """Starting from (start, t0), is there a way to survive all the current bombs"""
    if last_danger[start[0], start[1]] <= t0:
        return True
    queue = deque([(start, t0)])
    seen = {(start, t0)}
    while queue:
        (px, py), t = queue.popleft()
        if t >= horizon:
            return True
        for dx, dy in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = px + dx, py + dy
            if (dx, dy) != (0, 0):
                if not (0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]):
                    continue
                if field[nx, ny] != 0 or (nx, ny) in blocked:
                    continue
            if danger[t + 1, nx, ny]:
                continue
            if last_danger[nx, ny] <= t + 1:
                return True
            if ((nx, ny), t + 1) not in seen:
                seen.add(((nx, ny), t + 1))
                queue.append(((nx, ny), t + 1))
    return False


def bomb_is_useful(field, x, y, others):
    """To make sure whether the bomb can hit other agents"""
    for (cx, cy) in blast_coords(field, x, y):
        if field[cx, cy] == 1:
            return True
        if (cx, cy) in others:
            return True
    return False


def get_valid_actions(self, game_state, is_looping=False):
    """
    Escape, bomb placement, and normal movement share the same 
    timing sequence, ensuring that after completing this action, 
    there is still a movement that can survive all the current bombs.
    """
    field = game_state['field']
    x, y = game_state['self'][3]
    can_bomb = game_state['self'][2]
    bombs = game_state['bombs']
    explosion_map = game_state['explosion_map']
    bomb_xys = [b[0] for b in bombs]
    others = [o[3] for o in game_state['others']]

    horizon = danger_horizon(bombs, explosion_map)
    danger, last_danger = build_danger(field, bombs, explosion_map, horizon)
    blocked = set(bomb_xys)         

    legal, safe = [], []
    for a, (dx, dy) in MOVES:
        nx, ny = x + dx, y + dy
        if (dx, dy) != (0, 0):
            if field[nx, ny] != 0 or (nx, ny) in bomb_xys or (nx, ny) in others:
                continue
        legal.append(a)
        if danger[1, nx, ny]:
            continue
        if can_survive(field, (nx, ny), 1, danger, last_danger, blocked, horizon):
            safe.append(a)

    if can_bomb:
        sim_bombs = list(bombs) + [((x, y), BOMB_TIMER)]
        h2 = danger_horizon(sim_bombs, explosion_map)
        danger_b, last_b = build_danger(field, sim_bombs, explosion_map, h2)
        if not danger_b[1, x, y] and can_survive(field, (x, y), 1, danger_b, last_b,
                                                 blocked | {(x, y)}, h2):
            legal.append('BOMB')
            if bomb_is_useful(field, x, y, others) or is_looping:
                safe.append('BOMB')

    if not safe:
        return legal if legal else ['WAIT']

    # make sure the current safety
    if not danger[:, x, y].any():
        comfy = [a for a in safe
                 if a == 'BOMB' or not danger[:, x + DELTA[a][0], y + DELTA[a][1]].any()]
        if comfy:
            return comfy
    return safe


def act(self, game_state: dict) -> str:
    self.logger.info("Picking action using linear Q-model")
    
    if game_state['step'] == 1:
        if not self.train and self._test_last_state is not None:
            _log_test_round(self, self._test_last_state)
        self.last_position = None
        self._test_start_crates = int(np.sum(game_state['field'] == 1))
        self.position_history.clear()
        self.enemy_scores = {}

    self._test_last_state = game_state

    if not hasattr(self, 'enemy_scores'):
        self.enemy_scores = {}
    for other in game_state['others']:
        name, score, _, _ = other
        self.enemy_scores[name] = max(self.enemy_scores.get(name, 0), score)

    x, y = game_state['self'][3]
    self.position_history.append((x, y))
    is_looping = (len(self.position_history) == self.position_history.maxlen
                  and len(set(self.position_history)) <= 4)

    valid_actions = get_valid_actions(self, game_state, is_looping)
    self.logger.debug(f"Valid actions: {valid_actions}")

    features = state_to_features(game_state, prev_position=self.last_position,
                                 is_looping=is_looping)
    self.last_features = features
    self.last_position = (x, y)

    if is_looping:
        self.logger.debug("Agent is stuck in a loop. Attempting evasive maneuver.")
        if 'BOMB' in valid_actions:
            return 'BOMB'
        return random.choice(valid_actions)

    if self.train and random.random() < self.epsilon:
        self.logger.debug("Exploration active: Picking random valid action.")
        return random.choice(valid_actions)

    q_values = features @ self.model
    best_q = max(q_values[ACTIONS.index(a)] for a in valid_actions)
    best = [a for a in valid_actions if q_values[ACTIONS.index(a)] >= best_q - 1e-9]
    
    chosen_action = random.choice(best)
    self.logger.debug(f"Best Q-value {best_q:.4f} found for {best}. Chosen action: {chosen_action}")
    
    return chosen_action


def get_enemy_in_blast_zone(x, y, enemy_xys, field):
    for ex, ey in enemy_xys:
        if x == ex and abs(y - ey) <= BOMB_POWER:
            blocked = False
            for i in range(min(y, ey) + 1, max(y, ey)):
                if field[x, i] == -1 or field[x, i] == 1:
                    blocked = True
                    break
            if not blocked:
                return True
        if y == ey and abs(x - ex) <= BOMB_POWER:
            blocked = False
            for i in range(min(x, ex) + 1, max(x, ex)):
                if field[i, y] == -1 or field[i, y] == 1:
                    blocked = True
                    break
            if not blocked:
                return True
    return False


def state_to_features(game_state: dict, prev_position=None, is_looping=False) -> np.array:
    if game_state is None:
        return None

    field = game_state['field']
    _, _, can_bomb, (x, y) = game_state['self']
    bombs = game_state['bombs']
    explosion_map = game_state['explosion_map']
    coins = game_state['coins']
    enemy_xys = [other[3] for other in game_state['others']]

    wall_up    = 1 if field[x, y - 1] == -1 else 0
    wall_down  = 1 if field[x, y + 1] == -1 else 0
    wall_left  = 1 if field[x - 1, y] == -1 else 0
    wall_right = 1 if field[x + 1, y] == -1 else 0

    crate_adj_up    = 1 if field[x, y - 1] == 1 else 0
    crate_adj_down  = 1 if field[x, y + 1] == 1 else 0
    crate_adj_left  = 1 if field[x - 1, y] == 1 else 0
    crate_adj_right = 1 if field[x + 1, y] == 1 else 0

    enemy_adj_up    = 1 if (x, y - 1) in enemy_xys else 0
    enemy_adj_down  = 1 if (x, y + 1) in enemy_xys else 0
    enemy_adj_left  = 1 if (x - 1, y) in enemy_xys else 0
    enemy_adj_right = 1 if (x + 1, y) in enemy_xys else 0

    danger_map = np.zeros_like(field)
    danger_map[explosion_map > 0] = 1
    for (bx, by), t in bombs:
        for (cx, cy) in blast_coords(field, bx, by):
            danger_map[cx, cy] = 1

    im_in_danger = 1 if danger_map[x, y] > 0 else 0

    free_space = (field == 0)
    for (bx, by), t in bombs:
        free_space[bx, by] = False
    for ox, oy in enemy_xys:
        free_space[ox, oy] = False

    safe_dir = (0, 0)
    coin_dir = (0, 0)
    crate_dir = (0, 0)
    enemy_dir = (0, 0)

    if im_in_danger:
        safe_tiles = [(r, c) for r in range(field.shape[0]) for c in range(field.shape[1])
                      if danger_map[r, c] == 0 and free_space[r, c]]
        step, _ = look_for_targets(free_space, (x, y), safe_tiles)
        if step:
            safe_dir = (step[0] - x, step[1] - y)
    else:
        enemy_step, enemy_dist = look_for_targets(free_space, (x, y), enemy_xys)
        hunt_mode = enemy_step is not None and enemy_dist <= 4

        if hunt_mode:
            enemy_dir = (enemy_step[0] - x, enemy_step[1] - y)
            coin_step, coin_dist = look_for_targets(free_space, (x, y), coins)
            if coin_step and coin_dist <= 2:
                coin_dir = (coin_step[0] - x, coin_step[1] - y)
        else:
            coin_step, coin_dist = look_for_targets(free_space, (x, y), coins)
            if coin_step:
                coin_dir = (coin_step[0] - x, coin_step[1] - y)
            else:
                crates = [(r, c) for r in range(field.shape[0])
                          for c in range(field.shape[1]) if field[r, c] == 1]
                crate_step, _ = look_for_targets(free_space, (x, y), crates)
                if crate_step:
                    crate_dir = (crate_step[0] - x, crate_step[1] - y)

    back_dir = (0, 0)
    if prev_position is not None:
        px, py = prev_position
        if abs(px - x) + abs(py - y) == 1:
            back_dir = (px - x, py - y)

    enemy_in_blast = 1 if get_enemy_in_blast_zone(x, y, enemy_xys, field) else 0

    return np.array([
        wall_up, wall_down, wall_left, wall_right,
        im_in_danger,
        1 if safe_dir == (0, -1) else 0, 1 if safe_dir == (0, 1) else 0,
        1 if safe_dir == (-1, 0) else 0, 1 if safe_dir == (1, 0) else 0,
        1 if coin_dir == (0, -1) else 0, 1 if coin_dir == (0, 1) else 0,
        1 if coin_dir == (-1, 0) else 0, 1 if coin_dir == (1, 0) else 0,
        1 if crate_dir == (0, -1) else 0, 1 if crate_dir == (0, 1) else 0,
        1 if crate_dir == (-1, 0) else 0, 1 if crate_dir == (1, 0) else 0,
        1 if can_bomb else 0,
        1 if back_dir == (0, -1) else 0, 1 if back_dir == (0, 1) else 0,
        1 if back_dir == (-1, 0) else 0, 1 if back_dir == (1, 0) else 0,
        1 if enemy_dir == (0, -1) else 0, 1 if enemy_dir == (0, 1) else 0,
        1 if enemy_dir == (-1, 0) else 0, 1 if enemy_dir == (1, 0) else 0,
        enemy_in_blast,
        crate_adj_up, crate_adj_down, crate_adj_left, crate_adj_right,
        1 if is_looping else 0,
        enemy_adj_up, enemy_adj_down, enemy_adj_left, enemy_adj_right
    ])


def look_for_targets(free_space, start, targets):
    if len(targets) == 0: return None, float('inf')
    if start in targets: return start, 0
    frontier = deque([start])
    parent_dict = {start: start}

    while frontier:
        current = frontier.popleft()
        if current in targets:
            curr = current
            dist = 0
            while parent_dict[curr] != start:
                curr = parent_dict[curr]
                dist += 1
            return curr, dist + 1

        cx, cy = current
        for nx, ny in [(cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)]:
            if 0 <= nx < free_space.shape[0] and 0 <= ny < free_space.shape[1]:
                if (nx, ny) not in parent_dict:
                    if free_space[nx, ny] or (nx, ny) in targets:
                        parent_dict[(nx, ny)] = current
                        frontier.append((nx, ny))
    return None, float('inf')

# Save basic results for each test round
def _log_test_round(self, final_state):
    agent_name = final_state['self'][0] 
    log_file_name = f"test_log_lq.csv" 
    log_file_path = os.path.join(AGENT_DIR, log_file_name)
    
    write_header = not os.path.isfile(log_file_path)
    field = final_state['field']
    remaining_crates = int(np.sum(field == 1))
    crates_destroyed_total = (self._test_start_crates or 0) - remaining_crates
    my_score = final_state['self'][1]
    steps = final_state['step']
    max_enemy_score = max(self.enemy_scores.values()) if getattr(self, 'enemy_scores', None) else 0

    with open(log_file_path, "a", newline="") as f:
        w = csv.writer(f)
        if write_header:
            w.writerow(["agent_name", "round", "steps", "my_score", "max_enemy_score", "crates_destroyed_total"])
        w.writerow([agent_name, final_state['round'], steps, my_score, max_enemy_score, crates_destroyed_total])

def _flush_test_log(self):
    if self._test_last_state is not None and not self._test_flushed:
        self._test_flushed = True
        _log_test_round(self, self._test_last_state)
