# Analysis of Expert Experience Transfer Mechanism During Bomberman DQN Training

In the current DQN algorithm architecture, the training process does not adopt a hard-coded approach of directly reading other agents' source code or splicing opponents' hidden states. Instead, it implicitly "injects" the excellent experience of rule_based_agent and peaceful_agent into the DQN model through three core paths: **Heuristic Feature Extraction**, **Action Safety Filtering**, and **Reward Shaping**.

---

## 1. Expert Heuristic Feature Extraction: Learning "Sense of Direction" from rule_based_agent

The core advantage of rule_based_agent lies in its precise global graph search and path planning capability (Breadth-First Search, BFS), which can accurately locate the optimal path to coins or crates under the current layout.

* Experience Extraction Mechanism:
  In the get_bfs_direction_list function of callbacks.py, the BFS pathfinding algorithm of the rule-based agent is explicitly integrated. The system evaluates the current map topology at each frame and generates the optimal movement direction toward coins, crates, or safe zones.
* Feature Space Mapping (S ∈ ℝ²¹):
  The computed 4-dimensional one-hot vector (bfs_dir_list: [UP, RIGHT, DOWN, LEFT]) is directly used as dimensions 2~5 of the neural network input features.
* Network Fitting Process:
  When the BFS-recommended direction (e.g., RIGHT) is activated as 1.0, the DQN network discovers through early trial-and-error exploration that if the currently output action is consistent with this feature channel, the subsequently obtained cumulative Q-value is significantly higher. Thus, during gradient updates, the DQN compresses and internalizes the high-dimensional graph search capability into the network weights.

---

## 2. Local Rules and Constraints: Learning "Survival Instinct" from peaceful_agent

The core advantage of peaceful_agent lies in its extremely high survival rate, with logic including precise calculation of bomb explosion countdowns, flame impact ranges, and safe refuge cells.

* Dynamic Danger Zone Modeling:
  In state_to_features, the program performs real-time physical simulation of all placed bombs on the map and their 4-cell extended flame range, generating a danger map danger_map.
* Action Safety Masking:
  In the act and get_valid_actions functions of callbacks.py, the safety filtering rules of peaceful_agent are inherited, pre-mask actions that cause wall collisions or invalid operations.
* Network Fitting Process:
  During exploration, the DQN is stripped of low-level "suicide" and "wall-collision" possibilities. By constraining the action selection space to the safe action set, the neural network skips the inefficient invalid exploration phase and quickly internalizes the baseline strategy of prioritizing survival.

---

## 3. Reward Shaping Mechanism: Guiding Behavioral Alignment

The rewards originally provided by the environment are very sparse (triggered only when collecting coins or killing opponents), easily leading to vanishing policy gradients. The system constructs a custom reward function (reward_shaping_events) to drive the DQN to imitate the decision tendencies of experts through positive and negative feedback:

* Learning "Efficient Collection" from rule_based_agent:
  - Coin Tendency Guidance: Compare the Manhattan distance to the target coin before and after a decision. Moving closer is rewarded +12.0 (e_MOVED_TOWARDS_COIN), moving away is penalized -12.0 (e_MOVED_AWAY_FROM_COIN).
  - Precise Wall Breaking: Only when the agent is adjacent to a crate and places a bomb, reward +25.0 (e_GOOD_BOMB); if placing a bomb meaninglessly in an open area, penalize -35.0 (e_BAD_BOMB).
* Learning "Rapid Evasion" from peaceful_agent:
  - Escaping Danger Zones: When the agent was in the bomb impact range in the previous frame and successfully transferred to a safe cell in this frame, give a high reward +30.0 (e_ESCAPED_DANGER); if actively entering a danger zone, heavily penalize -40.0 (e_ENTERED_DANGER).
* Suppressing Invalid Wandering and Oscillation:
  - Anti-oscillation Mechanism: Maintain a position_history queue recording the positions of the last 6 steps. Once it is detected that the agent is oscillating in a loop between two points, penalize -20.0 (e_STUCK_IN_LOOP), forcing the model to learn the continuous, efficient, and smooth movement habits of the rule-based agent.

---

## 4. Overall Flow Architecture of Experience Transfer Mechanism

+-------------------------------------------------------------------+
|                  Expert Agent Experience Source (Knowledge)       |
+-------------------------------------------------------------------+
                                  │
      ┌───────────────────────────┼───────────────────────────┐
      ▼                           ▼                           ▼
[High-Dim Graph Search (BFS)]  [Danger Map & Safety Filter]  [Implicit Behavior Preference]
      │                           │                           │
      ▼                           ▼                           ▼
Input Features: bfs_dir (4D)   Safe Action Set: get_valid  Reward Shaping
      │                           │                           │
      └───────────────────────────┼───────────────────────────┘
                                  │
                                  ▼
                     +--------------------------+
                     |   DQN Policy Network     |
                     |   (State -> Q-Values)    |
                     +--------------------------+
                                  │
                                  ▼
                     +--------------------------+
                     |   Replay Buffer (TD-Loss)|
                     |  Neural Network Weight  |
                     |  Parameters (θ) Fitting  |
                     +--------------------------+
