# 训练入口：train_dqn3.bat（四阶段增量训练，每个阶段是独立进程，通过磁盘文件续训）
#
# 【增量训练机制】
#   - my_saved_model.pt：Q 网络权重（callbacks.setup 启动时自动加载，评估也用它）
#   - trainer_state.pt ：训练器状态（优化器动量、epsilon、梯度步数、回合数）
#   两个文件在 setup_training 中加载、在每回合结束时写回，因此：
#   四个阶段之间、以及训练结束后再次运行 bat，都会在旧模型基础上继续，绝不从头开始。
#   只有手动删除这两个文件才会冷启动（网络结构改变时必须删除）。
import os;
import shutil;
import atexit;
import random;
import logging;
from collections import deque;
import numpy as np;
import torch;
import torch.nn as nn;
import torch.optim as optim;

import events as e;
from .callbacks import (DQN, state_to_features, ACTIONS, FEATURE_DIM, MOVE_ACTIONS,
                        blast_tiles, build_danger_map, bomb_escape_feasible);

# ------------------------- 超参数（遵守项目约束：小学习率、小奖励） -------------------------
BATCH_SIZE = 128;
GAMMA = 0.95;
LEARNING_RATE = 5e-5;        # 项目硬约束：5e-5 防止 Q 值发散
# 100k：五阶段总步数约 200k，buffer 需保留早期"健康导航/逃生"正样本，
# 防止后期高密度阶段的自爆样本把回放池完全占据（曾导致灾难性摇摆）
MEMORY_SIZE = 100000;
TARGET_UPDATE_STEPS = 1000;  # 每 1000 次梯度更新同步 target 网络
LOG_EVERY_STEPS = 200;
REPLAY_SAVE_EVERY = 10;      # 每 10 回合把 replay 落盘一次（跨阶段/续训关键）

EPSILON_START = 1.0;
EPSILON_END = 0.02;  # v7：对战阶段降低随机移动（5% 会链状打断 4 步逃生窗口）
# 按环境步数指数退火（比按回合衰减更稳健：早期每局仅几十步，按回合衰减虚高）
EPSILON_TAU = 25000.0;      # 25k 步≈0.40，50k≈0.22，100k≈0.11，150k≈0.07

# 放弹探索：前 BOMB_EXPLORE_START 步完全关闭（阶段1 纯金币课程）。
# 【教训】在无箱安全图里放弹只会产生与"移动"相关联的随机死亡数据，网络会学成
# "动=危险、原地 WAIT=安全"的瘫痪策略。逃生技能改在阶段2（0.30 低密度箱阵，
# 空地充足、逃生容易）开始学习；之后随课程自然迁移到高密度与对战。
BOMB_EXPLORE_START = 58000;  # 阶段1(纯金币)实测约 55k 步，必须覆盖整个阶段1
BOMB_EPSILON = 0.005;  # v7r2：降低随机放弹探索频率
# 放弹探索随训练推进指数衰减：后期随机放弹会频繁打断 4 步逃生窗口制造
# 高死亡率的噪声轨迹（训练日志中的"100% 自爆"主要来自此），续训阶段降到 ~0.2%
BOMB_EPSILON_TAU = 80000.0;

# ------------------------- 自定义塑形事件（只给奖励，不改变动作） -------------------------
MOVED_TOWARDS_COIN = "MOVED_TOWARDS_COIN";
MOVED_AWAY_FROM_COIN = "MOVED_AWAY_FROM_COIN";
CLOSER_TO_CRATE = "CLOSER_TO_CRATE";
FARTHER_FROM_CRATE = "FARTHER_FROM_CRATE";
# 安全状态下向最近敌人靠近/远离：教网络主动追击（危险时不发，不鼓励亡命冲锋）
CLOSER_TO_ENEMY = "CLOSER_TO_ENEMY";
FARTHER_FROM_ENEMY = "FARTHER_FROM_ENEMY";
# 自己的炸弹爆炸（自己存活）时，爆炸前一一刻有敌人在该弹火力线内：瞄准兑现
AIMED_BOMB_EXPLODE = "AIMED_BOMB_EXPLODE";
FOLLOW_GUIDE_SAFE = "FOLLOW_GUIDE_SAFE";
FOLLOW_GUIDE_ESCAPE = "FOLLOW_GUIDE_ESCAPE";
# 危险格中：移动到另一危险格但方向不符合 BFS 逃生推荐（在走廊里越逃越深）
WRONG_DANGER_MOVE = "WRONG_DANGER_MOVE";
# 危险格中：BFS 给出了逃生方向却原地 WAIT（浪费逃生窗口）
DANGER_IDLE = "DANGER_IDLE";
ENTERED_DANGER = "ENTERED_DANGER";
ESCAPED_DANGER = "ESCAPED_DANGER";
BAD_BOMB = "BAD_BOMB";
TRAPPED_BOMB = "TRAPPED_BOMB";
GOOD_BOMB_CRATE = "GOOD_BOMB_CRATE";
GOOD_BOMB_ENEMY = "GOOD_BOMB_ENEMY";
# 自己的炸弹爆炸时自己仍然存活（game_events_occurred 只对存活 agent 触发，
# 因此该事件天然只在"放弹后活到爆炸"时发放，把放弹收益与生存绑定）
BOMB_SURVIVED = "BOMB_SURVIVED";

# 死亡终止步中作废的"战利品"事件：自爆/同归于尽不允许获得任何正收益
DEATH_FORFEIT_EVENTS = (e.COIN_COLLECTED, e.COIN_FOUND, e.CRATE_DESTROYED,
                        e.KILLED_OPPONENT);
STUCK_IN_LOOP = "STUCK_IN_LOOP";
WAITED_TOO_LONG = "WAITED_TOO_LONG";
STEP_COST = "STEP_COST";

# ------------------------- 奖励表（缩小量纲，防止 Q 值发散） -------------------------
REWARD_TABLE = {
    # 环境原生事件（量纲整体缩小：防止高价值目标使 Q 饱和、淹没死亡惩罚）
    e.COIN_COLLECTED: 5.0,
    e.COIN_FOUND: 1.0,
    e.CRATE_DESTROYED: 2.0,
    e.KILLED_OPPONENT: 20.0,
    # 自杀时框架同时发 KILLED_SELF + GOT_KILLED，合计 -40，为全表最强信号
    e.KILLED_SELF: -20.0,
    e.GOT_KILLED: -20.0,
    e.SURVIVED_ROUND: 1.0,
    e.INVALID_ACTION: -0.5,
    e.WAITED: -0.2,
    e.BOMB_DROPPED: 0.0,      # 好坏由 GOOD/BAD/TRAPPED_BOMB 塑形决定
    # 自定义塑形事件
    MOVED_TOWARDS_COIN: 0.5,
    MOVED_AWAY_FROM_COIN: -0.25,
    CLOSER_TO_CRATE: 0.15,
    FARTHER_FROM_CRATE: -0.05,
    CLOSER_TO_ENEMY: 0.3,   # 安全时向敌人靠近（为瞄准放弹创造机会）
    FARTHER_FROM_ENEMY: -0.1,
    AIMED_BOMB_EXPLODE: 0.3,  # 存活 + 自己炸弹爆炸时敌人恰在火力线（瞄准兑现）
    FOLLOW_GUIDE_SAFE: 0.5,   # 安全时沿 BFS 推荐方向移动（强于空等，防瘫痪）
    FOLLOW_GUIDE_ESCAPE: 1.5, # 危险时沿逃生推荐方向移动（最强塑形，直接教逃生）
    WRONG_DANGER_MOVE: -1.0,  # 危险中不按逃生 BFS 方向走（死角往往由此进入）
    DANGER_IDLE: -0.5,        # 危险中 BFS 给了逃生路却 WAIT
    ENTERED_DANGER: -2.5,
    ESCAPED_DANGER: 1.5,
    BAD_BOMB: -4.0,  # v7r2：无效弹惩罚加倍，压制"乱放弹"频率
    # 放弹后 3 步内无路可逃：即时重罚（学习率仅 5e-5，延迟死亡信号传播太慢）
    TRAPPED_BOMB: -12.0,  # v7r2：绝境放弹重罚加大
    GOOD_BOMB_CRATE: 0.0,  # 箱子收益仍延迟到爆炸步（+2/箱），不放当步奖励
    # 敌人在火力线内且 3 步内有逃生路：放弹当步给小瞄准奖励（教"对准敌人再放"，
    # 而非随机放弹）；无逃生路时 TRAPPED_BOMB(-12) 同时生效，净奖励仍为强负
    GOOD_BOMB_ENEMY: 0.5,
    BOMB_SURVIVED: 1.0,    # 自己的炸弹爆炸且自己存活才发放（与 CRATE +2 同步到达）
    STUCK_IN_LOOP: -1.0,
    WAITED_TOO_LONG: -1.0,
    STEP_COST: -0.01,
};

MODEL_FILE = "my_saved_model.pt";
TRAINER_FILE = "trainer_state.pt";
REPLAY_FILE = "replay_buffer.pt";
# 各训练阶段结束时的累计回合数（与 train_dqn3.bat 的 --n-rounds 严格对齐）：
# 在这些回合冻结模型+训练器快照，供选模与回退（replay 不复制，体积大且非必需）
STAGE_SNAPSHOT_ROUNDS = {
    250: "stage1", 550: "stage2", 850: "stage3", 1250: "stage4",
    1550: "stage5", 1850: "stage6", 2250: "stage7", 2850: "stage8",
};


def _agent_dir():
    return os.path.dirname(__file__);


def _epsilon_at(env_steps):
    """按环境总步数指数退火（状态可持久化，跨阶段/跨进程连续）"""
    return EPSILON_END + (EPSILON_START - EPSILON_END) * float(np.exp(-env_steps / EPSILON_TAU));


def _bomb_epsilon_at(env_steps):
    """放弹探索：课程点前为 0，之后 1% 起指数衰减（纯无偏探索，不含策略）"""
    if env_steps < BOMB_EXPLORE_START:
        return 0.0;
    return BOMB_EPSILON * float(np.exp(-(env_steps - BOMB_EXPLORE_START) / BOMB_EPSILON_TAU));


def _save_replay(self):
    """把 replay buffer 落盘（每个 bat 阶段是独立进程，必须跨进程保住经验分布）"""
    path = os.path.join(_agent_dir(), REPLAY_FILE);
    tmp = path + ".tmp";
    torch.save(list(self.memory), tmp);
    os.replace(tmp, path);


def _load_replay(self):
    path = os.path.join(_agent_dir(), REPLAY_FILE);
    if os.path.isfile(path):
        try:
            data = torch.load(path, map_location='cpu', weights_only=False);
            self.memory = deque(data, maxlen=MEMORY_SIZE);
            self.logger.info(f"[INCREMENTAL] Replay restored: {len(self.memory)} transitions");
        except Exception as ex:
            self.logger.warning(f"Replay restore failed ({ex}); starting empty buffer.");


def setup_training(self):
    """初始化训练资源；若磁盘上有权重/训练器状态则完整恢复（增量训练）"""
    self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu");

    # callbacks.setup 已创建 self.model 并加载过权重；直接复用，保证权重延续
    self.policy_net = self.model.to(self.device);
    self.policy_net.train();
    self.target_net = DQN(input_dim=FEATURE_DIM, output_dim=len(ACTIONS)).to(self.device);
    self.target_net.load_state_dict(self.policy_net.state_dict());
    self.target_net.eval();

    self.optimizer = optim.Adam(self.policy_net.parameters(), lr=LEARNING_RATE);
    self.criterion = nn.SmoothL1Loss();  # Huber loss，比 MSE 更抗发散
    self.memory = deque(maxlen=MEMORY_SIZE);

    self.epsilon = EPSILON_START;
    self.steps_done = 0;
    self.round_count = 0;
    self.env_steps = 0;
    self._last_loss = 0.0;

    # 行为统计（用于训练日志）
    self._pos_history = deque(maxlen=6);
    self._wait_streak = 0;
    # 最近一次自己放弹的位置（用于 BOMB_EXPLODED 时做火力线归因）
    self._last_bomb_pos = None;

    # 训练日志文件（追加，便于跨阶段查看完整曲线）
    self._log_fh = logging.FileHandler(os.path.join(_agent_dir(), "train.log"), mode='a');
    self._log_fh.setLevel(logging.INFO);
    self._log_fh.setFormatter(logging.Formatter('[%(asctime)s] %(message)s'));
    self.logger.addHandler(self._log_fh);

    # ---- 恢复训练器状态（优化器动量/epsilon/计数），实现真正的增量训练 ----
    trainer_path = os.path.join(_agent_dir(), TRAINER_FILE);
    model_path = os.path.join(_agent_dir(), MODEL_FILE);
    if os.path.isfile(trainer_path) and os.path.isfile(model_path):
        state = torch.load(trainer_path, map_location=self.device);
        self.optimizer.load_state_dict(state['optimizer']);
        self.steps_done = int(state.get('steps_done', 0));
        self.round_count = int(state.get('round_count', 0));
        self.env_steps = int(state.get('env_steps', 0));
        self.epsilon = _epsilon_at(self.env_steps);
        self.logger.info(
            f"[INCREMENTAL] Resumed: rounds={self.round_count}, "
            f"grad_steps={self.steps_done}, epsilon={self.epsilon:.4f}"
        );
    else:
        self.logger.info("[FRESH] No trainer state found, training from scratch.");

    # ---- 恢复 replay buffer（bat 五阶段为 5 个独立进程，不恢复等于每阶段从零学）----
    _load_replay(self);

    self.bomb_epsilon = _bomb_epsilon_at(self.env_steps);

    # 进程正常结束时兜底落盘一次 replay（阶段末尾的经验不丢）
    atexit.register(_save_replay, self);


def game_events_occurred(self, old_game_state, self_action, new_game_state, events):
    """每步回调：计算塑形奖励、存入回放池、执行一次梯度更新"""
    if old_game_state is None or self_action is None or new_game_state is None:
        return;

    self.env_steps += 1;
    self.epsilon = _epsilon_at(self.env_steps);
    self.bomb_epsilon = _bomb_epsilon_at(self.env_steps);
    old_features = state_to_features(old_game_state);
    new_features = state_to_features(new_game_state);

    old_pos = old_game_state['self'][3];
    new_pos = new_game_state['self'][3];
    coins = old_game_state['coins'];
    field = old_game_state['field'];
    others = [o[3] for o in old_game_state['others']];

    shaping = [STEP_COST];

    # --- 金币距离塑形 ---
    if coins:
        old_d = min(abs(old_pos[0] - c[0]) + abs(old_pos[1] - c[1]) for c in coins);
        new_d = min(abs(new_pos[0] - c[0]) + abs(new_pos[1] - c[1]) for c in coins);
        if new_d < old_d:
            shaping.append(MOVED_TOWARDS_COIN);
        elif new_d > old_d:
            shaping.append(MOVED_AWAY_FROM_COIN);

    # --- 木箱距离塑形 ---
    crates = [(cx, cy) for cx in range(field.shape[0]) for cy in range(field.shape[1])
              if field[cx, cy] == 1];
    if crates:
        old_cd = min(abs(old_pos[0] - c[0]) + abs(old_pos[1] - c[1]) for c in crates);
        new_cd = min(abs(new_pos[0] - c[0]) + abs(new_pos[1] - c[1]) for c in crates);
        if new_cd < old_cd:
            shaping.append(CLOSER_TO_CRATE);
        elif new_cd > old_cd:
            shaping.append(FARTHER_FROM_CRATE);

    # --- 敌人距离塑形：仅在"移动前后都安全"时发放 ---
    # 危险时一切以逃生为先（ENTERED_DANGER/FOLLOW_GUIDE_ESCAPE 主导），
    # 避免网络为了 +0.3 追击奖励而冲进炸弹火力线。
    if others and old_features[0] == 0.0 and new_features[0] == 0.0:
        old_ed = min(abs(old_pos[0] - o[0]) + abs(old_pos[1] - o[1]) for o in others);
        new_others = [o[3] for o in new_game_state['others']];
        if new_others:
            new_ed = min(abs(new_pos[0] - o[0]) + abs(new_pos[1] - o[1]) for o in new_others);
            if new_ed < old_ed:
                shaping.append(CLOSER_TO_ENEMY);
            elif new_ed > old_ed:
                shaping.append(FARTHER_FROM_ENEMY);

    # --- 采纳 BFS 推荐方向（参考特征）的奖励：网络可自由选择是否采纳 ---
    follow_escape = False;
    if self_action in MOVE_ACTIONS:
        guide_idx = MOVE_ACTIONS.index(self_action);
        if old_features[9 + guide_idx] > 0.0:
            if old_features[0] > 0.0:
                shaping.append(FOLLOW_GUIDE_ESCAPE);
                follow_escape = True;  # 沿 BFS 逃生路穿 timer>=2 的格子不算违规
            else:
                shaping.append(FOLLOW_GUIDE_SAFE);

    # --- 危险进出塑形：教会网络自己避险（动作仍是网络选的，不做任何强制） ---
    # 任何"从安全格踏入危险格"都罚 ENTERED_DANGER（包括躲开自己炸弹后又走回
    # 火焰臂的自杀行为）；唯一例外：正沿 BFS 逃生路线穿过远期(timer>=2)危险格。
    was_in_danger = old_features[0] > 0.0;
    now_in_danger = new_features[0] > 0.0;
    if not was_in_danger and now_in_danger and not follow_escape:
        shaping.append(ENTERED_DANGER);
    elif was_in_danger and not now_in_danger:
        shaping.append(ESCAPED_DANGER);

    # 危险中的动作质量（BFS 给出了逃生方向 guide 时才评判，无路可走时不叠加）
    if was_in_danger and sum(old_features[9:13]) > 0.0:
        if self_action in MOVE_ACTIONS:
            if now_in_danger and not follow_escape:
                shaping.append(WRONG_DANGER_MOVE);
        elif self_action == 'WAIT':
            shaping.append(DANGER_IDLE);

    # --- 放弹质量塑形：炸得到箱子/敌人，且必须留有 3 步内可达的逃生路 ---
    if self_action == 'BOMB':
        tiles = set(blast_tiles(field, old_pos[0], old_pos[1]));
        n_crates = sum(1 for (tx, ty) in tiles if field[tx, ty] == 1);
        hit_enemy = any((tx, ty) in others for (tx, ty) in tiles);
        old_danger = build_danger_map(field, old_game_state['bombs'],
                                      old_game_state['explosion_map']);
        feasible = bomb_escape_feasible(field, old_pos,
                                        [b[0] for b in old_game_state['bombs']],
                                        others, old_danger) > 0.0;
        if not feasible:
            shaping.append(TRAPPED_BOMB);
        # 记录放弹位置，供 4 步后 BOMB_EXPLODED 做火力线归因
        self._last_bomb_pos = (old_pos[0], old_pos[1]);
        # 瞄准敌人 + 有逃生路：放弹当步小奖励，把"放弹"动作与"敌人在火力线"
        # 直接关联（解决随机乱放弹）；若无路可逃，TRAPPED_BOMB(-8) 压过 +0.5。
        if hit_enemy and feasible:
            shaping.append(GOOD_BOMB_ENEMY);
        # 箱子收益延迟到爆炸步（+2/箱，死亡作废），杜绝"同归于尽赚分"。
        if n_crates == 0 and not hit_enemy:
            shaping.append(BAD_BOMB);

    # --- 震荡检测：最近 6 步只出现在至多 2 个格子上 ---
    self._pos_history.append(new_pos);
    if len(self._pos_history) == 6 and len(set(self._pos_history)) <= 2:
        shaping.append(STUCK_IN_LOOP);

    # --- 连续 WAIT 检测 ---
    if self_action == 'WAIT':
        self._wait_streak += 1;
        if self._wait_streak >= 3:
            shaping.append(WAITED_TOO_LONG);
    else:
        self._wait_streak = 0;

    all_events = list(events) + shaping;
    # 自己的炸弹爆炸而本回调仍被调用 = 自己存活：放弹收益只在此刻发放
    n_exploded = sum(1 for ev in events if ev == e.BOMB_EXPLODED);
    for _ in range(n_exploded):
        all_events.append(BOMB_SURVIVED);
        # 爆炸瞬间（用爆炸前 old_state 的位置）有敌人在这颗弹的火力线内：
        # 瞄准兑现奖励（敌人可能逃开没被炸死，但"对准了再放"的动作得到强化）
        if self._last_bomb_pos is not None:
            bx, by = self._last_bomb_pos;
            blast = set(blast_tiles(field, bx, by));
            if any(o in blast for o in others):
                all_events.append(AIMED_BOMB_EXPLODE);
    reward = reward_from_events(all_events);
    action_idx = ACTIONS.index(self_action);

    self.memory.append((old_features, action_idx, reward, new_features, False));
    # 每环境步 2 次梯度（LR 不变，加速 -40 死亡信号沿 4-5 步逃生链反向传播）
    _optimize(self);
    _optimize(self);

    if self.env_steps % LOG_EVERY_STEPS == 0:
        self.logger.info(
            f"step={self.env_steps:6d} round={self.round_count:5d} "
            f"eps={self.epsilon:.4f} loss={self._last_loss:.4f} buffer={len(self.memory)}"
        );


def end_of_round(self, last_game_state, last_action, events):
    """回合结束：终止 transition 入池、epsilon 衰减、保存权重与训练器状态"""
    self.round_count += 1;

    if last_game_state is not None and last_action is not None:
        last_features = state_to_features(last_game_state);
        shaping = [STEP_COST];
        # 致命动作的即时塑形：框架对死亡 agent 跳过 game_events_occurred，
        # 因此"走入即刻致命格"的 ENTERED_DANGER 在正常回调里永远收不到。
        # 在终止 transition 上补齐，让 -5 与 -50 死亡罚直接绑定到致命动作。
        died = e.KILLED_SELF in events or e.GOT_KILLED in events;
        if died and last_action in MOVE_ACTIONS:
            idx = MOVE_ACTIONS.index(last_action);
            if last_features[1 + idx] >= 1.0:  # 目标邻居紧迫度=1：本步即爆/正在燃烧
                shaping.append(ENTERED_DANGER);
        # 死亡步：战利品全部作废（自爆/同归于尽不得获得箱子、金币、击杀正收益）
        terminal_events = [ev for ev in events if not (died and ev in DEATH_FORFEIT_EVENTS)];
        reward = reward_from_events(terminal_events + shaping);
        action_idx = ACTIONS.index(last_action) if last_action in ACTIONS else ACTIONS.index('WAIT');
        # 终止态：next 用零向量、done=True
        self.memory.append((last_features, action_idx, reward,
                           np.zeros(FEATURE_DIM, dtype=np.float32), True));
        _optimize(self);
        _optimize(self);

    # epsilon 由环境总步数确定（确定性退火，跨进程连续，无需按回合衰减）
    self.epsilon = _epsilon_at(self.env_steps);

    # ---- 每回合持久化：权重 + 训练器状态（增量训练的关键） ----
    model_path = os.path.join(_agent_dir(), MODEL_FILE);
    torch.save(self.policy_net.state_dict(), model_path);
    torch.save({
        'optimizer': self.optimizer.state_dict(),
        'epsilon': self.epsilon,
        'steps_done': self.steps_done,
        'round_count': self.round_count,
        'env_steps': self.env_steps,
    }, os.path.join(_agent_dir(), TRAINER_FILE));

    # 定期落盘 replay（跨阶段进程的经验连续性）
    if self.round_count % REPLAY_SAVE_EVERY == 0:
        _save_replay(self);

    # 每个训练阶段结束回合冻结快照（模型+训练器），供跨阶段选模与回退
    if self.round_count in STAGE_SNAPSHOT_ROUNDS:
        tag = STAGE_SNAPSHOT_ROUNDS[self.round_count];
        adir = _agent_dir();
        shutil.copy(os.path.join(adir, MODEL_FILE),
                    os.path.join(adir, f"{tag}_model.pt"));
        shutil.copy(os.path.join(adir, TRAINER_FILE),
                    os.path.join(adir, f"{tag}_trainer.pt"));
        self.logger.info(f"[SNAPSHOT] {tag} checkpoint frozen at round {self.round_count}.");

    total_reward = reward_from_events(list(events));
    self.logger.info(
        f"ROUND {self.round_count} end | native_event_reward={total_reward:.1f} "
        f"eps={self.epsilon:.4f} grad_steps={self.steps_done}"
    );


def _optimize(self):
    """Double DQN 梯度更新：policy 选动作、target 估值"""
    if len(self.memory) < BATCH_SIZE:
        return;

    batch = random.sample(self.memory, BATCH_SIZE);
    states, actions, rewards, next_states, dones = zip(*batch);

    states_t = torch.FloatTensor(np.array(states)).to(self.device);
    actions_t = torch.LongTensor(actions).unsqueeze(1).to(self.device);
    rewards_t = torch.FloatTensor(rewards).unsqueeze(1).to(self.device);
    next_states_t = torch.FloatTensor(np.array(next_states)).to(self.device);
    dones_t = torch.FloatTensor(dones).unsqueeze(1).to(self.device);

    q_values = self.policy_net(states_t).gather(1, actions_t);

    with torch.no_grad():
        # 从特征重建物理合法性掩码，bootstrap 时不许选择物理不可执行的动作
        # （features[5:9]=四向通行, features[18]=可放弹, WAIT 恒合法）
        legal = torch.zeros(BATCH_SIZE, 6, device=self.device);
        legal[:, 0:4] = (next_states_t[:, 5:9] > 0.5).float();
        legal[:, 4] = 1.0;
        legal[:, 5] = (next_states_t[:, 18] > 0.5).float();
        policy_next_q = self.policy_net(next_states_t).masked_fill(legal < 0.5, float('-inf'));
        next_actions = policy_next_q.argmax(dim=1, keepdim=True);
        next_q = self.target_net(next_states_t).gather(1, next_actions);
        target_q = rewards_t + (1.0 - dones_t) * GAMMA * next_q;

    loss = self.criterion(q_values, target_q);
    self.optimizer.zero_grad();
    loss.backward();
    torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), max_norm=1.0);
    self.optimizer.step();

    self.steps_done += 1;
    self._last_loss = loss.item();
    if self.steps_done % TARGET_UPDATE_STEPS == 0:
        self.target_net.load_state_dict(self.policy_net.state_dict());


def reward_from_events(events) -> float:
    """将事件列表（原生 + 自定义塑形）汇总为标量奖励"""
    total = 0.0;
    for ev in events:
        total += REWARD_TABLE.get(ev, 0.0);
    return total;
