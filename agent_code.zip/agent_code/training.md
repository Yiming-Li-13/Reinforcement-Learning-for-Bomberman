# Phase 1: Simple Pathfinding and Coin Collection (Coin Heaven Scenario)
python main.py play --train 1 --agents dqn_agent3 --scenario coin-heaven --no-gui --n-rounds 400

# Phase 2: Wall Breaking and Crate Looting with Evasion (Loot Crate Scenario)
python main.py play --train 1 --agents dqn_agent3 --scenario loot-crate --no-gui --n-rounds 600

# Phase 3: 1v1 Single-Enemy Combat (Classic Scenario)
python main.py play --train 1 --agents dqn_agent3 rule_based_agent --scenario classic --no-gui --n-rounds 800

# Phase 4: 4-Player Full Melee Complete Training (Classic Scenario)
python main.py play --train 1 --agents dqn_agent3 rule_based_agent rule_based_agent rule_based_agent --scenario classic --no-gui --n-rounds 1000
