Game runtime callback program callbacks.py. I found that this training model is not very useful; in callbacks.py, many places still use BFS strategy. Now please help me modify train.py and callbacks.py, so that train.py can truly be suitable for learning the experience of agents like rule_based_agent and coin_collector_agent, forming the model we want, and then use this model to implement callbacks.py. The current LLM session process is in "训练会话_20260910.md"

To solve the problem you mentioned — "the training model is not very useful, callbacks.py still heavily relies on BFS hard-coded logic" — the root cause is that the previously implemented Feature Representation and behavior control pattern are disconnected.

If we only feed the BFS-calculated direction as a 4-dimensional one-hot feature to the neural network, while directly using BFS hard-coding to take over actions in callbacks.py, the DQN network becomes a "decoration"; and if we directly let the DQN explore from scratch, the high-dimensional BombeRMan state space will cause the DQN to converge extremely slowly, or even fail to learn the core essence of the target Agent (such as coin_collector_agent and rule_based_agent).

Here is a complete code solution for refactoring and strengthening train.py and callbacks.py.

1. Core Improvement Approach for Code Refactoring
Strong Guidance Features and State Feature Alignment:

Unify the feature extraction state_to_features in callbacks.py and train.py. Decompose the 21-dimensional feature matrix into:

BFS optimal navigation direction (4-dimensional One-Hot): the first-step direction calculated by BFS to reach the nearest coin/nearest crate/danger-avoidance exit.

Surrounding 4-cell terrain status (4-dimensional): numerical encoding of walls, crates, danger zones, and safe passages.

Danger and bomb cooldown status (4-dimensional): whether the current position is within the bomb blast range, the remaining countdown to explosion, and the bomb placement cooling status.

Relative position to target/crate/enemy (9-dimensional): normalized local features.

Hybrid Policy and True End-to-End Decision Chain (callbacks.py):

Abandon the approach of directly running BFS to dominate decisions in callbacks.py.

The act function in callbacks.py is fully delegated to the DQN model to predict the Q-values of 6 actions.

Only after the network outputs Q-values, use a Rule-based Safety Filter to filter out invalid actions (Invalid Actions) that "directly hit walls" or "enter absolutely lethal danger zones", and execute the optimal legal action in descending Q-value order.

Implicit Mechanism Migration and High-Efficiency Reward Shaping (train.py):

Absorb coin_collector_agent experience: introduce Manhattan distance and BFS step count change detection. A step toward the coin is rewarded +10.0, moving away is penalized -10.0, and collecting a coin gives +100.0.

Absorb rule_based_agent experience:

When in the bomb blast range, if the action makes an "evasion move", an additional reward of +25.0; if it goes deeper into the danger zone, a heavy penalty of -50.0.

When placing a bomb at an effective position adjacent to a crate/enemy, give a +30.0 incentive; meaningless random bomb placement is penalized -40.0.

Action smoothing and dead-loop removal: add a penalty (-15.0) for "oscillating back and forth between 2 consecutive cells / dead loops" and a penalty (-10.0) for "meaningless Wait".
