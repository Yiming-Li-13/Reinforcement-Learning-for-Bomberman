# Activity Mechanism of Player dqn_agent3 During Bomberman Training

Throughout the training cycle, dqn_agent3 is not a randomly exploring individual acting blindly, but rather participates in the game as an autonomous decision-making entity with basic safety defense, real-time trial-and-error through environmental interaction, and continuous iterative optimization in the background. Its complete activity lifecycle can be divided into the following 5 core phases:

---

## 1. State Perception

In each frame of the game environment, dqn_agent3 receives the raw environment state game_state and triggers the feature extraction pipeline:

* Danger Map Modeling: Based on the timers and explosion flame radiation ranges of all bombs on the current map, a danger zone map danger_map is generated in real time.
* Heuristic Path Planning: The Breadth-First Search (BFS) algorithm runs in parallel in the background to locate the optimal movement vector toward the nearest coin, crate, or safe evasion cell.
* State Vector Generation: The global map topology and individual state are compressed and abstracted into a fixed 21-dimensional low-dimensional feature vector S ∈ ℝ²¹, serving as the input to the policy network.

---

## 2. Decision & Action Masking

When selecting specific actions, dqn_agent3 adopts a two-layer decision architecture combining the Epsilon-Greedy exploration strategy and an Action Safety Filter:

* Dynamic Exploration Mechanism (Epsilon-Greedy):
  - Early Training (ε ≈ 1.0): Executes random actions with high probability, actively expanding the coverage of the state space.
  - Late Training (ε decays to 0.05): Gradually converges to the greedy policy, prioritizing the action with the highest Q-value predicted by the Policy Network.
* Safety Masking:
  - The policy network outputs the estimated Q-values of 6 discrete actions [UP, RIGHT, DOWN, LEFT, WAIT, BOMB] and sorts them from largest to smallest.
  - dqn_agent3 traverses the sorted action list, verifying whether the action is in the safe action set (get_valid_actions).
  - Prioritizes executing the legal action with the highest Q-value that does not trigger wall collision or suicide, ensuring a baseline survival rate.

---

## 3. Environmental Interaction & Experience Replay

dqn_agent3 sends the selected action A to the game engine, driving the environment to evolve into the next frame state S', and receives immediate feedback:

* Reward Shaping:
  - Positive Incentives: Approaching coin (+12.0), successfully escaping danger zone (+30.0), placing bomb adjacent to crate (+25.0).
  - Negative Penalties: Moving away from coin (-12.0), actively entering danger zone (-40.0), meaningless bomb placement (-35.0), oscillating in place (-20.0).
* Experience Collection:
  - Stores the transition tuple (S, A, R, S', done) of the current step into the Replay Buffer with a capacity of 50,000, providing training samples for offline learning.

---

## 4. Model Training & Evolution

After the experience data accumulated in the Replay Buffer reaches BATCH_SIZE (128), dqn_agent3 triggers gradient updates in the background:

* Sampling and TD Error Calculation: Randomly samples 128 historical transitions from the experience pool, and uses the Target Network to compute the Bellman target Q-value.
* Gradient Backpropagation: Uses Huber Loss (Smooth L1 Loss) to evaluate the deviation between the predicted Q-value and the target Q-value, and updates the Policy Network's weight parameters through the Adam optimizer (LR = 0.0003).
* Target Network Synchronization: Every 500 training steps, the weights of the Policy Network are deep-copied to the Target Network, ensuring the numerical stability of Q-value estimation.

---

## 5. End of Round & Policy Decay

When a single game ends (death or reaching the upper limit of 400 steps), dqn_agent3 completes the round cycle:

* Terminal State Storage: Pushes the terminal data with done = True into the experience pool, triggering a single-round learning update.
* Exploration Rate Decay: Decays the ε value at a rate of 0.998, reducing the probability of random exploration in the next round and increasing the utilization of the learned policy.
* Weight Persistence: Automatically serializes and overwrites the updated neural network weights to my_saved_model.pt, completing the phased policy evolution.
