# Run command: python main.py play --agents dqn_agent3 rule_based_agent rule_based_agent rule_based_agent --scenario classic --n-rounds 3 --update-interval 0.08 --no-gui
#
# [Design Principle] This file contains no hardcoded game strategy (no hardcoded danger-avoidance / coin-collection / crate-bombing / bomb-placement rules).
# Action selection is 100% determined by the trained DQN network:
#   - get_legal_actions only filters actions that are "physically impossible to execute" (stone walls / wooden crates / bombs / enemy occupation),
#     which is a physical legality mask for the action space, not a strategy; walking into flames, placing a bomb that kills yourself, etc. are all allowed,
#     and the network learns to avoid them on its own through reward signals.
#   - The BFS pathfinding result is only fed to the network as a 4-dimensional "recommended direction feature" for reference (the path-planning feature recommended by the final_project document).
#     The network may either adopt or ignore it, and it is never used in act() to directly determine actions.
import os;
from collections import deque;
import numpy as np;
import torch;
import torch.nn as nn;

ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT', 'WAIT', 'BOMB'];


DIRS = [(0, -1), (1, 0), (0, 1), (-1, 0)];
MOVE_ACTIONS = ['UP', 'RIGHT', 'DOWN', 'LEFT'];


FEATURE_DIM = 26;


class DQN(nn.Module):
    """Q Network: FEATURE_DIM -> 128 -> 128 -> 64 -> 6"""

    def __init__(self, input_dim, output_dim):
        super(DQN, self).__init__();
        self.fc = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, output_dim)
        );

    def forward(self, x):
        return self.fc(x);


def setup(self):
    """Create the DQN network and load pre-trained weights if available (for evaluation and incremental training)."""
    self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu");
    self.model = DQN(input_dim=FEATURE_DIM, output_dim=len(ACTIONS)).to(self.device);

    model_path = os.path.join(os.path.dirname(__file__), "my_saved_model.pt");
    if os.path.exists(model_path):
        self.model.load_state_dict(torch.load(model_path, map_location=self.device));
        self.logger.info("Loaded model from " + model_path);
    else:
        self.logger.info("No pre-trained model found, using fresh weights.");
    self.model.eval();


def act(self, game_state: dict) -> str:
    """
    Decision-making for actions: train with epsilon-greedy exploration, evaluate with network argmax.
    - Action set is filtered by physical legality (walls / crates / bombs / enemy occupation).
    - Whether to avoid risks, place bombs, or wait is determined by the network Q Q-values.
    """
    if game_state is None:
        return 'WAIT';

    legal_actions = get_legal_actions(game_state);
    features = state_to_features(game_state);

   # epsilon-greedy exploration (epsilon is set by setup_training in train.py)
    # [Curricular exploration] Random exploration is performed only among movement/WAIT actions, to avoid high-frequency random bomb placement early on causing
    # self-detonation within seconds each round; bomb-placement exploration is handled through a separate low-probability bomb_epsilon (scheduled by train.py
    # according to the number of training steps, being 0 in the early stage and enabled only after learning to move), ensuring that the BOMB action still has a small number of
    # unbiased samples to learn from. Whether to place a bomb is ultimately still determined by the network's Q-values.
    if self.train and np.random.rand() < self.epsilon:
        explore_set = [a for a in legal_actions if a != 'BOMB'];
        return np.random.choice(explore_set if explore_set else legal_actions);

    if self.train and 'BOMB' in legal_actions and np.random.rand() < getattr(self, 'bomb_epsilon', 0.0):
        return 'BOMB';

    features_tensor = torch.FloatTensor(features).unsqueeze(0).to(self.device);
    with torch.no_grad():
        q_values = self.model(features_tensor).squeeze(0).cpu().numpy();

    # 物理合法性掩码：仅把不可执行动作屏蔽，其余全部交给网络排序
    masked_q = np.full_like(q_values, -np.inf);
    for action in legal_actions:
        masked_q[ACTIONS.index(action)] = q_values[ACTIONS.index(action)];

    return ACTIONS[int(np.argmax(masked_q))];


def get_legal_actions(game_state: dict) -> list:
    """
    Return only physically executable actions (not strategy!):
      - Movement: the target cell is within bounds, is an empty cell (field==0), has no bomb, and is not occupied by another agent.
        Flame cells do not block movement (walking into them will kill you, but this is a strategic choice the network needs to learn to avoid).
      - WAIT: always legal.
      - BOMB: executable only when the bomb cooldown has ended (self[2]==True). Whether placing a bomb is safe is learned by the network.
    """
    x, y = game_state['self'][3];
    field = game_state['field'];
    bomb_positions = [b[0] for b in game_state['bombs']];
    others = [o[3] for o in game_state['others']];

    legal = [];
    for i, (dx, dy) in enumerate(DIRS):
        nx, ny = x + dx, y + dy;
        if not (0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]):
            continue;
        if field[nx, ny] != 0:
            continue;  # 石墙(-1)/木箱(1)阻挡
        if (nx, ny) in bomb_positions or (nx, ny) in others:
            continue;  # 炸弹/敌人占据
        legal.append(MOVE_ACTIONS[i]);

    legal.append('WAIT');

    if game_state['self'][2]:
        legal.append('BOMB');

    return legal;



def build_danger_map(field: np.ndarray, bombs: list, explosion_map: np.ndarray) -> np.ndarray:
    """
    Danger countdown map: 0 = safe; >0 = this cell will be covered by flames after `timer` steps (the value is the countdown of the nearest bomb).
    Consistent with the game's actual explosions (see items.get_blast_coords): flames are blocked only by stone walls (-1),
    and will pass through wooden crates (1) and continue extending; the crate cell itself is also a danger cell.
    """
    danger = np.zeros(field.shape, dtype=np.int32);
    danger[explosion_map > 0] = 1;  # 当前正在燃烧的火焰最危险
    for (bx, by), timer in bombs:
        
        dv = timer + 1;
        
        if danger[bx, by] == 0 or danger[bx, by] > dv:
            danger[bx, by] = dv;
        for dx, dy in DIRS:
            for dist in range(1, 4):
                nx, ny = bx + dx * dist, by + dy * dist;
                if not (0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]):
                    break;
                if field[nx, ny] == -1:  # 仅石墙阻挡
                    break;
                
                if danger[nx, ny] == 0 or danger[nx, ny] > dv:
                    danger[nx, ny] = dv;
    return danger;


def blast_tiles(field: np.ndarray, bx: int, by: int) -> list:
    
    tiles = [(bx, by)];
    for dx, dy in DIRS:
        for dist in range(1, 4):
            nx, ny = bx + dx * dist, by + dy * dist;
            if not (0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]):
                break;
            if field[nx, ny] == -1:
                break;
            tiles.append((nx, ny));
    return tiles;


def bomb_escape_feasible(field, pos, bomb_positions, others, danger_map) -> float:
    
    x, y = pos;
    blast = set(blast_tiles(field, x, y));
    blocked = set(bomb_positions) | set(others);
    visited = {(x, y)};
    queue = deque([((x, y), 0)]);
    while queue:
        (cx, cy), depth = queue.popleft();
        if depth > 0 and (cx, cy) not in blast and danger_map[cx, cy] == 0:
            return 1.0;
        if depth >= 3:
            continue;
        for dx, dy in DIRS:
            nx, ny = cx + dx, cy + dy;
            if not (0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]):
                continue;
            if field[nx, ny] != 0 or (nx, ny) in blocked or (nx, ny) in visited:
                continue;
            visited.add((nx, ny));
            queue.append(((nx, ny), depth + 1));
    return 0.0;


def _bfs_first_step(field, start, targets, danger_map, blocked, allow_danger_deep=False):
    """
    BFS to find the first-step direction from start to the nearest target in targets.
    blocked: additional set of blocked cells (bomb positions / enemy positions).
    allow_danger_deep: during dangerous escape, allow passing through danger cells with timer>=2 (except for the first step;
      the target must be a safe cell). In the safe state, all danger cells are excluded unconditionally.
    Returns a [UP, RIGHT, DOWN, LEFT] one-hot; returns all zeros if there is no path.
    """
    if not targets:
        return [0.0, 0.0, 0.0, 0.0];
    target_set = set(targets);
    blocked_set = set(blocked);
    queue = deque([(start, None, 0)]);
    visited = {start};
    while queue:
        (cx, cy), first_dir, depth = queue.popleft();
        if (cx, cy) in target_set and first_dir is not None:
            vec = [0.0, 0.0, 0.0, 0.0];
            vec[first_dir] = 1.0;
            return vec;
        for i, (dx, dy) in enumerate(DIRS):
            nx, ny = cx + dx, cy + dy;
            if not (0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]):
                continue;
            if (nx, ny) in visited or field[nx, ny] != 0:
                continue;
            if (nx, ny) in blocked_set:
                continue;
            d = danger_map[nx, ny];
            if allow_danger_deep:
                # 逃生搜索：允许穿过 timer>=2 的格，禁止火焰/timer==1 的格
                if d == 1 and (nx, ny) not in target_set:
                    continue;
            else:
                # 常规导航：排除一切未来爆炸区
                if d > 0:
                    continue;
            visited.add((nx, ny));
            new_first = first_dir if first_dir is not None else i;
            queue.append(((nx, ny), new_first, depth + 1));
    return [0.0, 0.0, 0.0, 0.0];


def recommended_direction(field, pos, coins, crates, others, bomb_positions, danger_map):
    """
    [Recommended direction feature, does not take over actions]
    When in danger: recommend the escape direction toward the nearest safe cell (BFS depth <= 3);
    When safe: first recommend the direction of the nearest coin; if there is no path, recommend the direction of the nearest "empty cell adjacent to a wooden crate" (crate-bombing guidance).
    """
    x, y = pos;
    blocked = set(bomb_positions) | set(others);

    # 危险时：目标=所有安全空地
    if danger_map[x, y] > 0:
        safe_targets = [];
        for sx in range(field.shape[0]):
            for sy in range(field.shape[1]):
                if field[sx, sy] == 0 and danger_map[sx, sy] == 0 and (sx, sy) not in blocked:
                    safe_targets.append((sx, sy));
        return _bfs_first_step(field, pos, safe_targets, danger_map, blocked,
                               allow_danger_deep=True);

    # 安全时：金币优先
    guide = _bfs_first_step(field, pos, list(coins), danger_map, blocked);
    if sum(guide) > 0:
        return guide;

    # 金币无路：以"与木箱相邻的空地"为目标
    crate_adjacent = [];
    for (cx, cy) in crates:
        for dx, dy in DIRS:
            nx, ny = cx + dx, cy + dy;
            if (0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]
                    and field[nx, ny] == 0):
                crate_adjacent.append((nx, ny));
    return _bfs_first_step(field, pos, crate_adjacent, danger_map, blocked);


def state_to_features(game_state: dict) -> np.ndarray:
    """
    Extract a 26-dimensional feature vector (training/evaluation share the same pipeline to ensure consistent distributions):
    [0]      in_danger              whether the current cell is in a flame/bomb radiation zone
    [1..4]   neighbor danger urgency U,R,D,L  (0 safe ~ 1 about to explode; flame=1)
    [5..8]   neighbor physically passable U,R,D,L
    [9..12]  BFS recommended direction U,R,D,L    (reference feature, does not determine actions)
    [13,14]  relative displacement to nearest coin /32 (maximum Manhattan distance on a 17x17 board)
    [15,16]  relative displacement to nearest enemy /32
    [17]     adjacent wooden crate density (0~1)
    [18]     whether a bomb can be placed
    [19]     proportion of safe empty-cell neighbors
    [20]     current step count /400
    [21]     number of visible coins /9
    [22]     number of surviving enemies /3
    [23]     whether placing a bomb at this moment has an escape route reachable within 3 steps (BFS geometric feature, for reference only)
    [24]     whether the enemy is within the blast cells of "placing a bomb here and now" (aiming information; whether to place a bomb is decided by the network)
    [25]     Manhattan distance to the nearest enemy /32 (magnitude information for pursuing/creating distance)
    """
    features = np.zeros(FEATURE_DIM, dtype=np.float32);
    if game_state is None:
        return features;

    field = game_state['field'];
    _, _, can_bomb, (x, y) = game_state['self'];
    bombs = game_state['bombs'];
    explosion_map = game_state['explosion_map'];
    coins = game_state['coins'];
    others = [o[3] for o in game_state['others']];
    bomb_positions = [b[0] for b in bombs];
    step = game_state.get('step', 1);

    danger_map = build_danger_map(field, bombs, explosion_map);

    # [0] in_danger flag
    features[0] = 1.0 if danger_map[x, y] > 0 else 0.0;

    # [1..4] neighbor danger urgency
    safe_free = 0;
    for i, (dx, dy) in enumerate(DIRS):
        nx, ny = x + dx, y + dy;
        if not (0 <= nx < field.shape[0] and 0 <= ny < field.shape[1]):
            continue;
        dv = danger_map[nx, ny];
        if explosion_map[nx, ny] > 0:
            features[1 + i] = 1.0;
        elif dv > 0:
            features[1 + i] = float(np.clip((5 - dv) / 4.0, 0.25, 1.0));
        free = (field[nx, ny] == 0 and (nx, ny) not in bomb_positions and (nx, ny) not in others);
        features[5 + i] = 1.0 if free else 0.0;
        if free and dv == 0:
            safe_free += 1;
    features[19] = safe_free / 4.0;

   
    crates = [(cx, cy) for cx in range(field.shape[0]) for cy in range(field.shape[1])
              if field[cx, cy] == 1];
    guide = recommended_direction(field, (x, y), coins, crates, others,
                                  bomb_positions, danger_map);
    for i in range(4):
        features[9 + i] = guide[i];

    
    if coins:
        cx, cy = min(coins, key=lambda c: abs(c[0] - x) + abs(c[1] - y));
        features[13] = (cx - x) / 32.0;
        features[14] = (cy - y) / 32.0;

    
    nearest_enemy_dist = None;
    if others:
        ox, oy = min(others, key=lambda o: abs(o[0] - x) + abs(o[1] - y));
        features[15] = (ox - x) / 32.0;
        features[16] = (oy - y) / 32.0;
        nearest_enemy_dist = abs(ox - x) + abs(oy - y);
        features[25] = min(1.0, nearest_enemy_dist / 32.0);

    # [17] adjacent wooden crate density
    adjacent_crates = 0;
    for dx, dy in DIRS:
        nx, ny = x + dx, y + dy;
        if 0 <= nx < field.shape[0] and 0 <= ny < field.shape[1] and field[nx, ny] == 1:
            adjacent_crates += 1;
    features[17] = adjacent_crates / 4.0;

    # [18] bomb placement cooldown
    features[18] = 1.0 if can_bomb else 0.0;

    # [20] step count normalized            
    features[20] = min(1.0, step / 400.0);

    # [21] visible coin proportion /9
    features[21] = min(1.0, len(coins) / 9.0);

    # [22] surviving enemy proportion /3
    features[22] = min(1.0, len(others) / 3.0);

    # [23] bomb escape feasibility
    features[23] = bomb_escape_feasible(field, (x, y), bomb_positions, others, danger_map);

    # [24] enemy is within bomb placement blast cells   
    if others:
        my_blast = set(blast_tiles(field, x, y));
        features[24] = 1.0 if any(o in my_blast for o in others) else 0.0;

    return features;
