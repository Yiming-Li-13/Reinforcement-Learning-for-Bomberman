# Work 1
1. Read the callbacks.py and train.py files in this directory, then read the 技术方案.md and 学习过程.md files, and understand the implementation principle of DQN_agent3
2. Based on our previous discussions, check whether the current program meets our expectations. The training speed is very fast now, but the performance is poor. The biggest problem is that the agent kills itself with a bomb right at the start of the game
3. Analyze this problem. It may be caused by the game's initial state, or by the game's rules
4. If it is caused by the game's initial state, we can try to modify the game's initial state, or try to modify the game's rules
5. Whenever training starts, delete the my_saved_model.pt file in the directory
6. Training command: python main.py play --agents my_agent rule_based_agent coin_collector_agent peaceful_agent --train 1 --n-rounds 1000 --no-gui
7. According to the description in ..\doc\final_project.md, you can provide better training commands and parameter settings
8. The dqn_agent3 training result is still not good now, and it easily kills itself with bombs. Please help me check the current train.py program again, whether it supports incremental training. The current training command is train_dqn3.bat, please take a look at this training command. Modification requirements:
   - Support incremental training, i.e., after each training completion, training can continue rather than starting from scratch
   - In callbacks.py, hard-coding is not allowed. Do not directly write strategies for avoiding danger, collecting coins, breaking crates, or breaking walls. The learned strategy must be used to avoid danger, collect coins, break crates, break walls, etc.
   - After modification, you should still use the train_dqn3.bat command to train, rather than directly running the train.py file
   - After training is complete, you can check the my_saved_model.pt file and use the following command to test the model and check the model's performance
    python main.py play --agents dqn_agent3 rule_based_agent rule_based_agent rule_based_agent --scenario classic --n-rounds 3 --update-interval 0.08 --no-gui
   - If the model performance is not good, you can try to modify the game's initial state and continue training.
   - Training-testing is executed at most 10 times, from which the best model (i.e., the model with the highest score) is selected as the final model.

9. The dqn_agent3 training result has greatly improved now, but the win rate is not high. Please check the train.py and callbacks.py files again to see whether incremental training can be performed. Requirements:
    - Can add coin_collector_agent training and learning to collect coins
    - Can add peaceful_agent training and learning to avoid danger
    - Can add fail_agent training and learning to avoid danger
10. Please take another look at the two files train.py and callbacks.py of dqn_agent3, as well as the parameter settings, to see whether the model training and combat mode can be further improved. First provide modification suggestions, and I will decide whether to accept and whether to continue training
11. Now there is another problem: although our agent can actively drop bombs, the bomb dropping position is random, rather than based on the learned strategy. That is, it does not actively bomb enemies, and it drops many ineffective bombs, resulting in low game efficiency.
12. Below are your audit results and suggestions:
    ```Background monitoring results confirmed the aforementioned judgment: bat exits with a syntax error at the Phase 5 entry, and Phases 5-8 were not executed (the log only has 2 rounds of smoke testing). The current disk model is still the cand1 baseline, not polluted.
I will not modify any files for now, waiting for your decision: which items in the suggestion list to accept (my recommendation is ①②③⑧), and whether to wait until your GUI testing is finished before I act```
  Now I require:
   - Check the train_dqn3.bat command, requiring that on the basis of supporting incremental training, all training steps or phases be completed
   - The key point is that there is no bombing targeting "enemies" — it should actively bomb enemies, rather than dropping bombs randomly
   - Can add fail_agent training and learning to avoid danger
   - After modifying the program, you need to retrain the model and check the model's performance to see whether it has improved. If the improvement is small or there is no improvement, you can try to modify the program and retrain 5 more times, check the training results, and finally select the best model as the final model.
