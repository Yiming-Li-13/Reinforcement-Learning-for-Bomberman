# Bomberman Reinforcement Learning Algorithm Scheme Based on Deep Q-Network (DQN)

This scheme adopts a reinforcement learning architecture based on the Deep Q-Network (DQN), combined with heuristic rule feature extraction and Reward Shaping, enabling the agent to achieve safe evasion, path navigation, and efficient wall breaking in the Bomberman environment.

---

## 1. State Space & Feature Engineering

To reduce the complexity of the continuous environment and improve the convergence speed of the Q-network, the original environment state (game_state) is abstracted into a fixed 21-dimensional feature vector S ∈ ℝ²¹:

1. Danger Perception Features (6 dimensions)
   - in_danger (1 dimension): The danger coefficient of the current position, calculated based on the bomb explosion countdown and flame impact range (0.0 ~ 1.0).
   - danger_neighbors (1 dimension): The proportion of the 4 adjacent cells (up, down, left, right) that are in the danger zone.
   - surroundings (4 dimensions): The environment type of the adjacent cells up, right, down, and left (safe passage 0.0, crate 0.5, danger zone -0.8, wall -1.0).

2. Navigation and Path Features (4 dimensions)
   - bfs_dir_list (4 dimensions): The optimal movement direction one-hot code [UP, RIGHT, DOWN, LEFT] computed using Breadth-First Search (BFS). When in danger, it points to the nearest safe cell; when in a safe state, it points to the nearest coin or crate.

3. Relative Position and Target Features (4 dimensions)
   - coin_rel (2 dimensions): The normalized coordinate offset of the nearest coin relative to the agent (Δx/15, Δy/15).
   - enemy_rel (2 dimensions): The normalized coordinate offset of the nearest enemy relative to the agent (Δx/15, Δy/15).

4. Global and Self-State Features (7 dimensions)
   - crates_norm (1 dimension): The density of crates in adjacent cells (0.0 ~ 1.0).
   - can_bomb (1 dimension): The cooldown status of placing a bomb (1.0 means placeable, 0.0 means not placeable).
   - pos_norm (2 dimensions): The absolute normalized coordinates of the agent in the map (x/17, y/17).
   - step_norm (1 dimension): The normalized step count of the current round (step/400).
   - coins_count_norm (1 dimension): The proportion of remaining coins in the map.
   - others_count_norm (1 dimension): The proportion of remaining alive enemies in the map.

---

## 2. Neural Network Architecture

The Q-network is used to fit the state-action value function Q(S, A; θ), adopting a Multi-Layer Perceptron (MLP) structure:

- Input Layer: 21-dimensional vector (Input Dimension = 21)
- Hidden Layer 1: Fully Connected (21 -> 128) + ReLU
- Hidden Layer 2: Fully Connected (128 -> 128) + ReLU
- Hidden Layer 3: Fully Connected (128 -> 64) + ReLU
- Output Layer: Fully Connected (64 -> 6), corresponding to the Q-value predictions of 6 discrete actions [UP, RIGHT, DOWN, LEFT, WAIT, BOMB].

---

## 3. Action Selection & Safety Mask

The system adopts the Epsilon-Greedy strategy combined with a Safety Filter for decision-making:

1. Epsilon-Greedy Exploration: In the early training phase, actions are randomly selected with probability ε; as training progresses, ε gradually decays to a minimum value of 0.05 with a coefficient of 0.998.
2. Q-value Ranking and Safety Mask: After the network inference outputs the Q-values of 6 actions, the actions are sorted by Q-value from large to small, and the sorted actions are traversed, giving priority to selecting actions that exist in the legal safe action set (get_valid_actions), to avoid training damping caused by invalid actions (such as hitting walls) or suicidal actions.

---

## 4. Training & TD-Learning

The training process adopts the standard DQN algorithm with Experience Replay (Replay Buffer) and Target Network:

1. Experience Replay Buffer: Stores transition tuples (S, A, R, S', done) with a capacity of 50,000. Random sampling (Batch Size = 128) is used to break data correlation.
2. Bellman Target Value Calculation:
   - For non-terminal states (done = False):
     Target_Q = R + γ * max_{a'} Q_target(S', a'; θ^-)
   - For terminal states (done = True):
     Target_Q = R
   - The discount factor γ is set to 0.98.
3. Loss Function and Optimization: Uses Huber Loss (Smooth L1 Loss) to compute the error between the current network's predicted Q-value and Target_Q, applies gradient clipping (Max Norm = 1.0), and uses the Adam optimizer (LR = 0.0003) to update the Policy Network parameters.
4. Target Network Update: Every 500 training steps, the weights of the Policy Network are deep-copied to the Target Network.

---

## 5. Reward Shaping

To address the convergence difficulties caused by sparse rewards, in addition to the environment's built-in scoring events, the system integrates custom rewards for implicit experience transfer:

- Coin Tendency: Approaching coin (+12.0), moving away from coin (-12.0)
- Survival Evasion: Successfully escaping the danger zone (+30.0), actively entering the danger zone (-40.0)
- Efficient Wall Bombing: Placing a bomb next to a crate (+25.0), placing a bomb in an open area without crates (-35.0)
- Anti-oscillation Mechanism: Detected to be oscillating in place within the last 6 steps (-20.0)
- Basic Game Events: Collecting coin (+100.0), destroying crate (+35.0), killing enemy (+400.0), death (-350.0)
